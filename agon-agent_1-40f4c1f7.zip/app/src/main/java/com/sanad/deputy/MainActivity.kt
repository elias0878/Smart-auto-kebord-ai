package com.sanad.deputy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.SmartToy
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.sanad.deputy.core.App
import com.sanad.deputy.core.AppLanguage
import com.sanad.deputy.core.LocalAppLanguage
import com.sanad.deputy.core.t
import com.sanad.deputy.ui.screens.HomeScreen
import com.sanad.deputy.ui.screens.LiveScreen
import com.sanad.deputy.ui.screens.ModelsScreen
import com.sanad.deputy.ui.screens.SettingsScreen
import com.sanad.deputy.ui.theme.AgonAppTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        App.init(applicationContext)
        setContent {
            val config by App.configState.collectAsState()
            val direction = if (config.language == AppLanguage.AR) {
                LayoutDirection.Rtl
            } else {
                LayoutDirection.Ltr
            }
            CompositionLocalProvider(
                LocalLayoutDirection provides direction,
                LocalAppLanguage provides config.language
            ) {
                AgonAppTheme {
                    MainApp()
                }
            }
        }
    }
}

private data class TabItem(
    val route: String,
    val labelKey: String,
    val icon: ImageVector
)

private val tabs = listOf(
    TabItem("home", "tab_home", Icons.Outlined.Home),
    TabItem("live", "tab_live", Icons.Outlined.Chat),
    TabItem("models", "tab_models", Icons.Outlined.SmartToy),
    TabItem("settings", "tab_settings", Icons.Outlined.Settings)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp() {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text(t("app_name_long")) },
                actions = {
                    IconButton(onClick = {
                        val next = if (App.config.language == AppLanguage.AR) {
                            AppLanguage.EN
                        } else {
                            AppLanguage.AR
                        }
                        App.scope.launch { App.store?.setLanguage(next) }
                    }) {
                        Icon(
                            imageVector = Icons.Outlined.Language,
                            contentDescription = t("settings_language")
                        )
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                tabs.forEach { tab ->
                    NavigationBarItem(
                        selected = currentRoute == tab.route,
                        onClick = {
                            if (currentRoute != tab.route) {
                                navController.navigate(tab.route) {
                                    popUpTo("home") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = t(tab.labelKey)
                            )
                        },
                        label = { Text(t(tab.labelKey)) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("home") { HomeScreen() }
            composable("live") { LiveScreen() }
            composable("models") { ModelsScreen() }
            composable("settings") { SettingsScreen() }
        }
    }
}
