package com.sanad.deputy.ui.screens

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.sanad.deputy.core.App
import com.sanad.deputy.core.AppLanguage
import com.sanad.deputy.core.t
import com.sanad.deputy.ui.components.SectionCard
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen() {
    val config by App.configState.collectAsState()

    var persona by remember(config.persona) { mutableStateOf(config.persona) }
    var memory by remember(config.memory) { mutableStateOf(config.memory) }

    LaunchedEffect(persona) {
        delay(700)
        if (persona != App.config.persona) {
            App.scope.launch { App.store?.setPersona(persona) }
        }
    }
    LaunchedEffect(memory) {
        delay(700)
        if (memory != App.config.memory) {
            App.scope.launch { App.store?.setMemory(memory) }
        }
    }

    LazySettings {
        // ------------------------------------------------------- language
        item {
            SectionCard(
                title = t("settings_language"),
                icon = Icons.Outlined.Language
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = config.language == AppLanguage.AR,
                        onClick = { App.scope.launch { App.store?.setLanguage(AppLanguage.AR) } },
                        label = { Text("العربية") }
                    )
                    FilterChip(
                        selected = config.language == AppLanguage.EN,
                        onClick = { App.scope.launch { App.store?.setLanguage(AppLanguage.EN) } },
                        label = { Text("English") }
                    )
                }
            }
        }

        // -------------------------------------------------------- persona
        item {
            SectionCard(
                title = t("settings_persona"),
                subtitle = t("settings_persona_hint"),
                icon = Icons.Outlined.Psychology
            ) {
                OutlinedTextField(
                    value = persona,
                    onValueChange = { persona = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp),
                    label = { Text(t("settings_persona")) },
                    placeholder = { Text(t("settings_persona_placeholder")) },
                    shape = RoundedCornerShape(16.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                ChipRow(
                    items = personaPresets(config.language),
                    onPick = { preset ->
                        persona = if (persona.isBlank()) {
                            preset
                        } else {
                            persona.trimEnd() + "\n" + preset
                        }
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = t("settings_characters").format(persona.length),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // --------------------------------------------------------- memory
        item {
            SectionCard(
                title = t("settings_memory"),
                subtitle = t("settings_memory_hint"),
                icon = Icons.Outlined.Memory
            ) {
                OutlinedTextField(
                    value = memory,
                    onValueChange = { memory = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(230.dp),
                    label = { Text(t("settings_memory")) },
                    placeholder = { Text(t("settings_memory_placeholder")) },
                    shape = RoundedCornerShape(16.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                ChipRow(
                    items = memoryPresets(config.language),
                    onPick = { preset ->
                        memory = if (memory.isBlank()) {
                            preset
                        } else {
                            memory.trimEnd() + "\n" + preset
                        }
                    }
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = t("settings_characters").format(memory.length),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (memory.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    androidx.compose.material3.TextButton(
                        onClick = {
                            memory = ""
                            App.scope.launch { App.store?.setMemory("") }
                        }
                    ) {
                        Text(t("settings_reset"))
                    }
                }
            }
        }

        // ------------------------------------------------------- behaviour
        item {
            SectionCard(
                title = t("settings_behavior"),
                icon = Icons.Outlined.Timer
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = t("settings_signature_lock"),
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = t("settings_signature_lock_desc"),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = config.signatureLock,
                        onCheckedChange = { value ->
                            App.scope.launch { App.store?.setSignatureLock(value) }
                        }
                    )
                }
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "${t("settings_stability")} · ${config.stabilitySeconds}${t("seconds_short")}",
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = t("settings_stability_desc"),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Slider(
                    value = config.stabilitySeconds.toFloat(),
                    onValueChange = { value ->
                        val seconds = value.toInt()
                        App.scope.launch { App.store?.setStability(seconds) }
                    },
                    valueRange = 1f..5f,
                    steps = 3
                )
            }
        }

        // ----------------------------------------------------------- about
        item {
            SectionCard(
                title = t("settings_about"),
                icon = Icons.Outlined.Info
            ) {
                Text(
                    text = t("settings_about_body"),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = t("settings_about_version").format("1.0.0"),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

/** A small wrapper so the settings content can use a lazy column. */
@Composable
private fun LazySettings(content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit) {
    androidx.compose.foundation.lazy.LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        content = content
    )
}

@Composable
private fun ChipRow(items: List<String>, onPick: (String) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items.forEach { label ->
            FilterChip(
                selected = false,
                onClick = { onPick(label) },
                label = { Text(label) }
            )
        }
    }
}

private fun personaPresets(language: AppLanguage): List<String> = if (language == AppLanguage.AR) {
    listOf(
        "أسلوب مهني رسمي ومختصر.",
        "أسلوب ودود وعامّي قريب من اللغة اليومية.",
        "أسلوب حكيم ومتزن مع نُكت خفيفة.",
        "أسلوب مباشر بلا مجاملات.",
        "دائماً رُد بالعربية الفصحى المبسّطة."
    )
} else {
    listOf(
        "Professional, formal and concise.",
        "Friendly, casual, everyday tone.",
        "Calm and wise with light humour.",
        "Direct, no small talk.",
        "Always reply in simple English."
    )
}

private fun memoryPresets(language: AppLanguage): List<String> = if (language == AppLanguage.AR) {
    listOf(
        "اسمي: …، عملي: …، نقيم في: …",
        "أكمل دراستي في … وأبحث عن …",
        "أسلوب كلامي المفضل: … / أتجنب: …",
        "أهدافي القادمة: …"
    )
} else {
    listOf(
        "My name is …, I work in …, I live in …",
        "I am studying … and looking for …",
        "My preferred tone: … / I avoid: …",
        "My upcoming goals: …"
    )
}
