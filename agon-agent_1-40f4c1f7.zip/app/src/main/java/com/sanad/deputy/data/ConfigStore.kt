package com.sanad.deputy.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.sanad.deputy.core.AppConfig
import com.sanad.deputy.core.AppLanguage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.configDataStore: DataStore<androidx.datastore.preferences.core.Preferences> by
    preferencesDataStore(name = "sanad_config")

/** Persistent store for the API key, persona, memory and agent behaviour. */
class ConfigStore(private val context: Context) {

    private object Keys {
        val apiKey = stringPreferencesKey("api_key")
        val model = stringPreferencesKey("model")
        val persona = stringPreferencesKey("persona")
        val memory = stringPreferencesKey("memory")
        val language = stringPreferencesKey("language")
        val autoPilot = booleanPreferencesKey("auto_pilot")
        val autoSend = booleanPreferencesKey("auto_send")
        val cooldown = intPreferencesKey("cooldown_seconds")
        val signatureLock = booleanPreferencesKey("signature_lock")
        val stability = intPreferencesKey("stability_seconds")
    }

    val configFlow: Flow<AppConfig> = context.configDataStore.data
        .catch { throwable ->
            if (throwable is IOException) emit(emptyPreferences()) else throw throwable
        }
        .map { prefs ->
            AppConfig(
                apiKey = prefs[Keys.apiKey].orEmpty(),
                model = prefs[Keys.model] ?: DEFAULT_MODEL,
                persona = prefs[Keys.persona].orEmpty(),
                memory = prefs[Keys.memory].orEmpty(),
                language = if (prefs[Keys.language] == AppLanguage.EN.code) AppLanguage.EN else AppLanguage.AR,
                autoPilot = prefs[Keys.autoPilot] ?: true,
                autoSend = prefs[Keys.autoSend] ?: true,
                cooldownSeconds = (prefs[Keys.cooldown] ?: 8).coerceIn(0, 300),
                signatureLock = prefs[Keys.signatureLock] ?: true,
                stabilitySeconds = (prefs[Keys.stability] ?: 2).coerceIn(1, 10)
            )
        }

    suspend fun setApiKey(value: String) = edit { it[Keys.apiKey] = value.trim() }

    suspend fun setModel(value: String) = edit { it[Keys.model] = value.trim() }

    suspend fun setPersona(value: String) = edit { it[Keys.persona] = value }

    suspend fun setMemory(value: String) = edit { it[Keys.memory] = value }

    suspend fun setLanguage(language: AppLanguage) = edit { it[Keys.language] = language.code }

    suspend fun setAutoPilot(value: Boolean) = edit { it[Keys.autoPilot] = value }

    suspend fun setAutoSend(value: Boolean) = edit { it[Keys.autoSend] = value }

    suspend fun setCooldown(seconds: Int) = edit { it[Keys.cooldown] = seconds.coerceIn(0, 300) }

    suspend fun setSignatureLock(value: Boolean) = edit { it[Keys.signatureLock] = value }

    suspend fun setStability(seconds: Int) = edit { it[Keys.stability] = seconds.coerceIn(1, 10) }

    private suspend fun edit(block: (MutablePreferences) -> Unit) {
        try {
            context.configDataStore.edit(block)
        } catch (io: IOException) {
            // The store is best-effort: never crash the caller because of a disk hiccup.
        }
    }

    companion object {
        const val DEFAULT_MODEL = "gemini-2.5-flash"
    }
}
