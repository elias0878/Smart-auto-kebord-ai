package com.sanad.deputy.service

import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Safe access to the accessibility window from any thread.
 *
 * `rootInActiveWindow` is fetched on the main looper (the only thread allowed to talk
 * to the system UI service) and then handed over to the background worker, which is
 * where the heavy traversal happens.
 */
object ReaderBridge {

    @Volatile
    var service: ScreenReaderService? = null

    fun isConnected(): Boolean = service != null

    fun root(): AccessibilityNodeInfo? {
        val svc = service ?: return null
        if (Looper.myLooper() == Looper.getMainLooper()) {
            return try {
                svc.rootInActiveWindow
            } catch (t: Throwable) {
                null
            }
        }
        val latch = CountDownLatch(1)
        var result: AccessibilityNodeInfo? = null
        try {
            Handler(Looper.getMainLooper()).post {
                try {
                    result = svc.rootInActiveWindow
                } catch (t: Throwable) {
                    result = null
                } finally {
                    latch.countDown()
                }
            }
            if (!latch.await(600, TimeUnit.MILLISECONDS)) return null
        } catch (t: Throwable) {
            return null
        }
        return result
    }
}

/** Holds the live IME so the agent can type into the focused field of other apps. */
object ImeBridge {

    @Volatile
    var service: AgentImeService? = null
}
