package com.sanad.deputy.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.sanad.deputy.core.App
import com.sanad.deputy.core.LogLevel
import com.sanad.deputy.core.t
import com.sanad.deputy.data.GeminiClient
import com.sanad.deputy.data.GeminiModel
import com.sanad.deputy.data.KeyTestResult
import com.sanad.deputy.ui.components.Pill
import com.sanad.deputy.ui.components.SectionCard
import kotlinx.coroutines.launch

@Composable
fun ModelsScreen() {
    val config by App.configState.collectAsState()
    var key by remember { mutableStateOf(config.apiKey) }
    var showKey by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<KeyTestResult?>(null) }
    var models by remember { mutableStateOf<List<GeminiModel>>(emptyList()) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    val labelSaved = t("models_key_saved")
    val labelNoKey = t("models_no_key")
    val labelBad = t("models_key_bad")
    val labelOk = t("models_key_ok")

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            SectionCard(
                title = t("models_api_key"),
                subtitle = t("models_title"),
                icon = Icons.Outlined.Key
            ) {
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(t("models_api_key")) },
                    placeholder = { Text(t("models_api_key_hint")) },
                    singleLine = true,
                    visualTransformation = if (showKey) {
                        VisualTransformation.None
                    } else {
                        PasswordVisualTransformation()
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    trailingIcon = {
                        IconButton(onClick = { showKey = !showKey }) {
                            Icon(
                                imageVector = if (showKey) {
                                    Icons.Outlined.VisibilityOff
                                } else {
                                    Icons.Outlined.Visibility
                                },
                                contentDescription = null
                            )
                        }
                    }
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = {
                            App.scope.launch {
                                App.store?.setApiKey(key)
                                App.log(labelSaved, LogLevel.OK)
                            }
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(t("save"))
                    }
                    FilledTonalButton(
                        onClick = {
                            if (key.isBlank()) {
                                error = labelNoKey
                                return@FilledTonalButton
                            }
                            error = null
                            testing = true
                            scope.launch {
                                val res = GeminiClient.testKey(key, config.model)
                                result = res
                                models = res.models
                                testing = false
                                if (!res.ok) {
                                    App.log("$labelBad: ${res.detail}", LogLevel.ERROR)
                                } else {
                                    App.log("$labelOk · ${res.models.size}", LogLevel.OK)
                                }
                            }
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp),
                        enabled = !testing
                    ) {
                        if (testing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                        }
                        Text(if (testing) t("models_testing") else t("models_test"))
                    }
                }
                if (error != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = error.orEmpty(),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }

        item {
            val res = result
            SectionCard(
                title = t("models_test"),
                icon = if (res?.ok == true) Icons.Outlined.CheckCircle else Icons.Outlined.ErrorOutline
            ) {
                if (res == null) {
                    Text(
                        text = t("models_test"),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Pill(
                            text = res.headline,
                            container = if (res.ok) {
                                MaterialTheme.colorScheme.primaryContainer
                            } else {
                                MaterialTheme.colorScheme.errorContainer
                            },
                            content = if (res.ok) {
                                MaterialTheme.colorScheme.onPrimaryContainer
                            } else {
                                MaterialTheme.colorScheme.onErrorContainer
                            }
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = res.detail, style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "${t("models_key_models")}: ${res.models.size}",
                        style = MaterialTheme.typography.titleSmall
                    )
                    if (res.models.isNotEmpty()) {
                        val best = res.models.maxByOrNull { it.inputTokenLimit }
                        if (best != null) {
                            Text(
                                text = t("models_key_limits_body")
                                    .format(best.inputTokenLimit, best.outputTokenLimit),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        val capabilities = res.models
                            .flatMap { it.methods }
                            .distinct()
                            .take(5)
                            .joinToString(", ")
                        if (capabilities.isNotBlank()) {
                            Text(
                                text = "${t("models_key_caps")}: $capabilities",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    if (res.generationProbe.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = t("models_key_generate_ok") + res.generationProbe,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    if (res.promptTokens > 0 || res.outputTokens > 0) {
                        Text(
                            text = "${t("models_in")}: ${res.promptTokens} · ${t("models_out")}: ${res.outputTokens}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            SectionCard(
                title = t("models_list"),
                icon = Icons.Outlined.Refresh
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${t("models_selected")}: ${config.model}",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f)
                    )
                    FilledTonalButton(
                        onClick = {
                            if (key.isBlank()) {
                                error = labelNoKey
                                return@FilledTonalButton
                            }
                            scope.launch {
                                GeminiClient.listModels(key)
                                    .onSuccess { models = it }
                                    .onFailure { error = it.message }
                            }
                        },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(t("refresh"))
                    }
                }
            }
        }

        if (models.isEmpty()) {
            item {
                Text(
                    text = t("models_list_empty"),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
        }

        items(models) { model ->
            ModelRow(
                model = model,
                active = model.shortName == com.sanad.deputy.data.GeminiClient.cleanModelName(config.model),
                onSelect = {
                    App.scope.launch { App.store?.setModel(model.shortName) }
                }
            )
        }
    }
}

@Composable
private fun ModelRow(
    model: GeminiModel,
    active: Boolean,
    onSelect: () -> Unit
) {
    SectionCard(modifier = Modifier.padding(bottom = 0.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = model.displayName,
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = model.shortName,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (active) {
                Pill(
                    text = "✓",
                    container = MaterialTheme.colorScheme.primaryContainer,
                    content = MaterialTheme.colorScheme.onPrimaryContainer
                )
            } else {
                FilledTonalButton(
                    onClick = onSelect,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(t("models_use"))
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Pill(text = "${t("models_in")} ${model.inputTokenLimit}")
            Pill(text = "${t("models_out")} ${model.outputTokenLimit}")
            if (model.supportsChat) {
                Pill(
                    text = "generateContent",
                    container = MaterialTheme.colorScheme.tertiaryContainer,
                    content = MaterialTheme.colorScheme.onTertiaryContainer
                )
            }
        }
    }
}
