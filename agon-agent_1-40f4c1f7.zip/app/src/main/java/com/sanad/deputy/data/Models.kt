package com.sanad.deputy.data

import android.graphics.Rect

/** A single chat bubble detected on screen. */
data class ParsedMessage(
    val text: String,
    val isMine: Boolean,
    val rect: Rect,
    /** 0..1 — how confident the ownership heuristic is. */
    val confidence: Float = 0f,
    /** Sender label detected right above the bubble (group chats). */
    val attribution: String? = null
)

/** Everything the perception engine understood about the current screen. */
data class ParsedScreen(
    val appPackage: String = "",
    val appLabel: String = "",
    val contactName: String? = null,
    val messages: List<ParsedMessage> = emptyList(),
    val isTyping: Boolean = false,
    val inputBounds: Rect? = null,
    val hasInputField: Boolean = false,
    val hasSendButton: Boolean = false,
    val screenWidth: Int = 0,
    val screenHeight: Int = 0,
    val isRtl: Boolean = false,
    val inspectedNodes: Int = 0,
    val parsedAt: Long = 0L
) {
    val lastMessage: ParsedMessage? get() = messages.lastOrNull()
    val mineCount: Int get() = messages.count { it.isMine }
    val theirsCount: Int get() = messages.count { !it.isMine }
    val averageConfidence: Float
        get() = if (messages.isEmpty()) 0f else messages.sumOf { it.confidence.toDouble() }.toFloat() / messages.size
}
