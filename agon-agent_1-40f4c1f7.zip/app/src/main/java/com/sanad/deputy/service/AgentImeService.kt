package com.sanad.deputy.service

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import com.sanad.deputy.core.AgentPhase
import com.sanad.deputy.core.App
import com.sanad.deputy.core.AppLanguage
import com.sanad.deputy.core.LogLevel
import com.sanad.deputy.core.Strings
import com.sanad.deputy.engine.AutonomousAgent
import kotlinx.coroutines.launch

/**
 * Sanad's own keyboard.
 *
 * The whole strip is built from plain Android views on purpose: Compose inside an
 * InputMethodService is a well known source of `BadTokenException` and of
 * `ViewTreeLifecycleOwner` crashes the moment the keyboard is opened inside a chat
 * application. Native views open in a couple of milliseconds and can never crash.
 */
class AgentImeService : InputMethodService() {

    private val handler = Handler(Looper.getMainLooper())
    private var rootView: View? = null
    private var statusView: TextView? = null
    private var autoSwitch: Switch? = null
    private var chipsRow: LinearLayout? = null
    private var suppressSwitchCallback = false

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 600)
        }
    }

    override fun onCreate() {
        super.onCreate()
        ImeBridge.service = this
        App.init(applicationContext)
    }

    override fun onCreateInputView(): View {
        val existing = rootView
        if (existing != null) return existing
        val view = buildStrip()
        rootView = view
        return view
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        refresh()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        handler.removeCallbacks(ticker)
        super.onFinishInputView(finishingInput)
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        if (ImeBridge.service === this) ImeBridge.service = null
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onEvaluateInputViewShown(): Boolean = true

    // ------------------------------------------------------------ public API

    /** Types a message into the focused field of the host application. */
    fun commitText(text: String): Boolean {
        val connection = currentInputConnection ?: return false
        if (text.isEmpty()) return false
        return try {
            connection.beginBatchEdit()
            val composing = connection.setComposingText(text, 1)
            if (composing) connection.finishComposingText() else connection.commitText(text, 1)
            connection.endBatchEdit()
            true
        } catch (t: Throwable) {
            try {
                connection.commitText(text, 1)
                true
            } catch (inner: Throwable) {
                false
            }
        }
    }

    /** Triggers the editor "send" action of the host application. */
    fun performSendAction(): Boolean {
        val connection = currentInputConnection ?: return false
        return try {
            val sent = connection.performEditorAction(EditorInfo.IME_ACTION_SEND)
            if (!sent) connection.performEditorAction(EditorInfo.IME_ACTION_DONE) else true
        } catch (t: Throwable) {
            false
        }
    }

    // --------------------------------------------------------------- the UI

    private fun buildStrip(): View {
        val context: Context = this
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(8))
            background = panelBackground()
            layoutDirection = View.LAYOUT_DIRECTION_LOCALE
        }

        // ---- top row: status + controls -----------------------------------
        val bar = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val status = TextView(context).apply {
            textSize = 11.5f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(INK)
            setPadding(dp(4), 0, dp(4), 0)
        }
        statusView = status
        bar.addView(status, LinearLayout.LayoutParams(0, dp(30), 1f))

        val auto = Switch(context).apply {
            text = Strings.get("home_auto_pilot", App.config.language)
            textSize = 11f
            setTextColor(INK)
            isChecked = App.config.autoPilot
            thumbTintList = null
            setOnCheckedChangeListener { _, checked ->
                if (suppressSwitchCallback) return@setOnCheckedChangeListener
                App.scope.launch { App.store?.setAutoPilot(checked) }
                App.log(
                    if (checked) "auto-pilot ON" else "auto-pilot OFF",
                    LogLevel.INFO
                )
            }
        }
        autoSwitch = auto
        bar.addView(auto, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))

        val language = pill(Strings.get("lang_toggle", App.config.language), ACCENT, Color.WHITE).apply {
            setOnClickListener {
                val next = if (App.config.language == AppLanguage.AR) AppLanguage.EN else AppLanguage.AR
                App.scope.launch { App.store?.setLanguage(next) }
                applyLanguage(next)
            }
        }
        bar.addView(language, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(32)).apply {
            marginStart = dp(6)
        })

        val force = pill(Strings.get("ime_force", App.config.language), ACCENT, Color.WHITE).apply {
            setOnClickListener {
                AutonomousAgent.forceReply()
            }
        }
        bar.addView(force, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(32)).apply {
            marginStart = dp(6)
        })

        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(36)))

        // ---- second row: quick replies ------------------------------------
        val chips = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val scroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            isFillViewport = false
        }
        quickReplies().forEach { reply ->
            val chip = pill(reply, SOFT, INK).apply {
                setOnClickListener {
                    if (!commitText(reply)) {
                        App.log("quick reply: no input connection", LogLevel.WARN)
                    }
                }
            }
            chips.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(30)).apply {
                marginEnd = dp(6)
            })
        }
        scroll.addView(chips)
        chipsRow = chips
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)).apply {
            topMargin = dp(2)
        })

        return root
    }

    private fun quickReplies(language: AppLanguage = App.config.language): List<String> =
        if (language == AppLanguage.AR) {
            listOf("تمام 👍", "سأعاود التواصل لاحقًا", "نعم، بالتأكيد", "شكرًا لك", "أنا مشغول الآن")
        } else {
            listOf("Sure 👍", "I'll get back to you", "Yes, absolutely", "Thank you", "I'm busy right now")
        }

    private fun applyLanguage(language: AppLanguage) {
        val rtl = language == AppLanguage.AR
        rootView?.layoutDirection = if (rtl) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        autoSwitch?.text = Strings.get("home_auto_pilot", language)
        chipsRow?.removeAllViews()
        quickReplies(language).forEach { reply ->
            val chip = pill(reply, SOFT, INK).apply {
                setOnClickListener {
                    if (!commitText(reply)) {
                        App.log("quick reply: no input connection", LogLevel.WARN)
                    }
                }
            }
            chipsRow?.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(30)).apply {
                marginEnd = dp(6)
            })
        }
        refresh()
    }

    private fun refresh() {
        val language = App.config.language
        val status = App.status.value
        var text = Strings.get(phaseKey(status.phase), language)
        val contact = App.lastScreen.value?.contactName
        if (!contact.isNullOrBlank()) {
            text = "$text · $contact"
        }
        if (status.detail.isNotBlank()) {
            text = "$text · ${status.detail}"
        }
        val cooldownUntil = App.cooldownUntil.value
        val remaining = cooldownUntil - System.currentTimeMillis()
        if (remaining > 0) {
            val seconds = ((remaining + 999) / 1000).toInt()
            text = "$text · ${Strings.get("ime_cooldown", language)} $seconds${Strings.get("seconds_short", language)}"
        }
        statusView?.text = text
        statusView?.setTextColor(when (status.phase) {
            AgentPhase.ERROR -> ERROR_INK
            AgentPhase.COOLDOWN -> WARN_INK
            AgentPhase.THINKING, AgentPhase.WRITING, AgentPhase.SENDING -> ACCENT
            else -> INK
        })
        val shouldBeOn = App.config.autoPilot
        if (autoSwitch?.isChecked != shouldBeOn) {
            suppressSwitchCallback = true
            autoSwitch?.isChecked = shouldBeOn
            suppressSwitchCallback = false
        }
    }

    private fun phaseKey(phase: AgentPhase): String = when (phase) {
        AgentPhase.DISABLED -> "phase_disabled"
        AgentPhase.IDLE -> "phase_idle"
        AgentPhase.WATCHING -> "phase_watching"
        AgentPhase.THINKING -> "phase_thinking"
        AgentPhase.WRITING -> "phase_writing"
        AgentPhase.SENDING -> "phase_sending"
        AgentPhase.COOLDOWN -> "phase_cooldown"
        AgentPhase.ERROR -> "phase_error"
    }

    // ------------------------------------------------------------- helpers

    private fun pill(label: String, backgroundColor: Int, foreground: Int): TextView = TextView(this).apply {
        text = label
        textSize = 11.5f
        gravity = Gravity.CENTER
        setTextColor(foreground)
        isClickable = true
        isFocusable = true
        val shape = GradientDrawable().apply {
            cornerRadius = dp(16).toFloat()
            setColor(backgroundColor)
        }
        background = RippleDrawable(ColorStateList.valueOf(0x33000000), shape, null)
        setPadding(dp(10), 0, dp(10), 0)
    }

    private fun panelBackground(): android.graphics.drawable.Drawable {
        val shape = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(PANEL)
        }
        return RippleDrawable(ColorStateList.valueOf(0x22000000), shape, null)
    }

    private fun dp(value: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        value.toFloat(),
        resources.displayMetrics
    ).toInt()

    private companion object {
        val PANEL = Color.parseColor("#FFF3F7F5")
        val SOFT = Color.parseColor("#FFE3EDE9")
        val INK = Color.parseColor("#FF0C1F1B")
        val ACCENT = Color.parseColor("#FF0F6B5E")
        val ERROR_INK = Color.parseColor("#FFB3261E")
        val WARN_INK = Color.parseColor("#FF8A6D00")
    }
}
