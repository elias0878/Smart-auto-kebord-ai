package com.sanad.deputy.engine

import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo
import com.sanad.deputy.core.AgentPhase
import com.sanad.deputy.core.App
import com.sanad.deputy.core.LogLevel
import com.sanad.deputy.core.Strings
import com.sanad.deputy.data.ConversationParser
import com.sanad.deputy.data.GeminiClient
import com.sanad.deputy.data.GeminiOutcome
import com.sanad.deputy.data.ParsedMessage
import com.sanad.deputy.data.ScreenAnalysis
import com.sanad.deputy.service.ImeBridge
import com.sanad.deputy.service.ReaderBridge
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicBoolean

/**
 * The autonomous loop.
 *
 * Guarantees implemented here:
 *  • Single flight — only one Gemini request may be in flight at any moment.
 *  • Pre-flight signature lock — the signature of a message is registered *before*
 *    the network call, so the very same message can never trigger a second request.
 *  • Self-action blindness — while the agent types and presses send, the reader is
 *    muted, and stays muted for two extra seconds so the sent bubble settles.
 *  • Safe cooldown — a configurable gap between requests plus an automatic 429 back-off.
 */
object AutonomousAgent {

    private const val PULSE_MS = 700L
    private const val SEND_WAIT_MS = 400L
    private const val BLIND_AFTER_MS = 2000L
    private const val RATE_LIMIT_COOLDOWN_MS = 30_000L
    private const val MAX_BACKOFF_MS = 120_000L
    private const val MAX_SIGNATURES = 12

    private val scope = CoroutineScope(
        SupervisorJob() + Dispatchers.Default + CoroutineExceptionHandler { _, throwable ->
            App.log(
                "Agent failure: ${throwable.javaClass.simpleName} — ${throwable.message}",
                LogLevel.ERROR
            )
            App.setStatus(AgentPhase.ERROR, throwable.message ?: "unknown")
        }
    )

    /** Single-flight lock for the whole network pipeline. */
    private val requestInFlight = AtomicBoolean(false)

    /** Guards the write + send section so two replies can never interleave. */
    private val writeMutex = Mutex()

    /** Guards the screen analysis so we never parse twice in parallel. */
    private val analysing = AtomicBoolean(false)

    @Volatile
    private var lastSignature: String? = null

    /** Bounded history of already handled messages (never answers the same one twice). */
    private val handledSignatures = ArrayDeque<String>()

    @Volatile
    private var blindUntil = 0L

    @Volatile
    private var nextAllowedAt = 0L

    @Volatile
    private var contentHash: String = ""

    @Volatile
    private var lastChangeAt = 0L

    private var pulseJob: Job? = null

    // -------------------------------------------------------------- lifecycle

    fun start() {
        if (pulseJob != null) return
        pulseJob = scope.launch {
            while (isActive) {
                delay(PULSE_MS)
                try {
                    tick(force = false)
                } catch (t: Throwable) {
                    App.log("Pulse failure: ${t.message}", LogLevel.WARN)
                }
            }
        }
    }

    /** Called by the accessibility service whenever a foreign screen changes. */
    fun signal(pkg: String?) {
        val now = System.currentTimeMillis()
        if (now < blindUntil) return
        scope.launch {
            try {
                tick(force = false, pkg = pkg)
            } catch (t: Throwable) {
                App.log("Signal failure: ${t.message}", LogLevel.WARN)
            }
        }
    }

    /** User pressed the "force reply" button: skip every waiting condition. */
    fun forceReply() {
        if (!ReaderBridge.isConnected()) {
            App.log(
                "reader service is not enabled — enable it from Android settings",
                LogLevel.WARN
            )
            App.setStatus(AgentPhase.ERROR, "reader service is not enabled")
            return
        }
        App.log(Strings.get("log_force", App.config.language), LogLevel.INFO)
        scope.launch {
            try {
                tick(force = true)
            } catch (t: Throwable) {
                App.log("Force reply failure: ${t.message}", LogLevel.ERROR)
            }
        }
    }

    // -------------------------------------------------------------- main loop

    private suspend fun tick(force: Boolean, pkg: String? = null) {
        val config = App.config
        if (!config.autoPilot && !force) {
            App.setStatus(AgentPhase.DISABLED)
            return
        }
        val now = System.currentTimeMillis()
        if (now < blindUntil) return
        if (!analysing.compareAndSet(false, true)) return
        try {
            val root = ReaderBridge.root()
            if (root == null) {
                App.setStatus(AgentPhase.IDLE, Strings.get("log_no_root", config.language))
                return
            }
            val analysis = ConversationParser.analyze(root, pkg ?: App.currentApp.value ?: "")
            if (analysis == null) {
                App.setStatus(AgentPhase.IDLE, Strings.get("log_parse_failed", config.language))
                return
            }
            val screen = analysis.screen
            App.setLastScreen(screen)
            App.setCurrentApp(screen.appPackage)

            // Never react to our own app.
            val ownPackage = App.appContext?.packageName
            if (ownPackage != null && screen.appPackage == ownPackage) {
                App.setStatus(AgentPhase.IDLE, "")
                return
            }

            val hash = screen.messages.joinToString("\u0001") { it.text }
            if (hash != contentHash) {
                contentHash = hash
                lastChangeAt = System.currentTimeMillis()
            }

            if (screen.messages.isEmpty()) {
                App.setStatus(AgentPhase.WATCHING, Strings.get("log_no_messages", config.language))
                return
            }

            if (screen.isTyping) {
                App.setStatus(AgentPhase.WATCHING, Strings.get("log_typing", config.language))
                return
            }

            val last = screen.messages.last()
            if (last.isMine) {
                // The user already answered — the agent stays completely silent.
                App.setStatus(AgentPhase.WATCHING, Strings.get("log_silent", config.language))
                return
            }

            val moment = System.currentTimeMillis()
            if (!force && moment < nextAllowedAt) {
                App.setCooldown(nextAllowedAt)
                App.setStatus(AgentPhase.COOLDOWN, Strings.get("log_cooldown", config.language))
                return
            }

            if (!force) {
                val settle = App.config.stabilitySeconds.coerceIn(1, 10) * 1000L
                if (moment - lastChangeAt < settle) {
                    App.setStatus(AgentPhase.WATCHING, Strings.get("log_wait_stability", config.language))
                    return
                }
            }

            respond(analysis, last, force)
        } finally {
            analysing.set(false)
        }
    }

    // --------------------------------------------------------------- replying

    private suspend fun respond(analysis: ScreenAnalysis, incoming: ParsedMessage, force: Boolean) {
        val config = App.config
        if (config.apiKey.isBlank()) {
            App.log(Strings.get("log_no_api_key", config.language), LogLevel.WARN)
            App.setStatus(AgentPhase.ERROR, Strings.get("log_no_api_key", config.language))
            return
        }
        if (!requestInFlight.compareAndSet(false, true)) {
            App.log(Strings.get("log_inflight", config.language), LogLevel.WARN)
            return
        }
        try {
            val contact = analysis.screen.contactName.orEmpty()
            val signature = "$contact|${incoming.text}"
            if (config.signatureLock && !force && isHandled(signature)) {
                App.log(Strings.get("log_signature_skip", config.language), LogLevel.INFO)
                return
            }
            // Pre-flight signature lock: registered before the network call.
            markHandled(signature)
            lastSignature = signature

            val cleanModel = GeminiClient.cleanModelName(config.model)
            if (cleanModel != config.model) {
                App.log(Strings.get("log_model_cleaned", config.language).format(cleanModel), LogLevel.INFO)
            }

            val system = PromptBuilder.systemInstruction(config, PromptBuilder.isArabic(incoming.text))
            val prompt = PromptBuilder.userPrompt(contact, analysis.screen.messages.takeLast(10))

            App.setStatus(AgentPhase.THINKING, Strings.get("phase_thinking", config.language))
            App.log(Strings.get("log_request_start", config.language) + " ($cleanModel)", LogLevel.INFO)
            App.bumpRequest()

            val outcome = GeminiClient.generate(config.apiKey, cleanModel, system, prompt)
            when (outcome) {
                is GeminiOutcome.Ok -> {
                    val reply = Sanitizer.clean(outcome.text)
                    if (reply.isBlank()) {
                        App.setStatus(AgentPhase.ERROR, Strings.get("log_empty_reply", config.language))
                        App.log(Strings.get("log_empty_reply", config.language), LogLevel.WARN)
                        return
                    }
                    App.log(Strings.get("log_request_ok", config.language), LogLevel.OK)
                    if (config.autoSend) {
                        App.setStatus(AgentPhase.WRITING, Strings.get("phase_writing", config.language))
                        blindUntil = System.currentTimeMillis() + SEND_WAIT_MS + BLIND_AFTER_MS
                        writeAndSend(reply, analysis)
                    } else {
                        App.setLastReply(reply)
                        App.setStatus(AgentPhase.IDLE, reply.take(80))
                        App.log("reply ready (auto-send off): $reply", LogLevel.INFO)
                    }
                }

                is GeminiOutcome.RateLimited -> {
                    val until = System.currentTimeMillis() + RATE_LIMIT_COOLDOWN_MS
                    nextAllowedAt = until
                    App.setCooldown(until)
                    App.setStatus(AgentPhase.COOLDOWN, Strings.get("log_rate_limited", config.language))
                    App.log(Strings.get("log_rate_limited", config.language), LogLevel.ERROR)
                }

                is GeminiOutcome.InvalidKey -> {
                    App.setStatus(AgentPhase.ERROR, Strings.get("log_invalid_key", config.language))
                    App.log(Strings.get("log_invalid_key", config.language), LogLevel.ERROR)
                }

                is GeminiOutcome.Failed -> {
                    App.setStatus(AgentPhase.ERROR, outcome.message.take(120))
                    App.log(Strings.get("log_request_failed", config.language) + ": " + outcome.message, LogLevel.ERROR)
                }
            }
        } catch (t: Throwable) {
            App.log("reply failure: ${t.message}", LogLevel.ERROR)
            App.setStatus(AgentPhase.ERROR, t.message ?: "error")
        } finally {
            val gap = App.config.cooldownSeconds.coerceIn(0, 300) * 1000L
            val candidate = System.currentTimeMillis() + gap
            // Never shorten an active back-off (for example after HTTP 429).
            if (candidate > nextAllowedAt) nextAllowedAt = candidate
            requestInFlight.set(false)
        }
    }

    // ----------------------------------------------------------- write & send

    private suspend fun writeAndSend(reply: String, analysis: ScreenAnalysis) {
        writeMutex.withLock {
            val ime = ImeBridge.service
            var written = false

            // 1. Focus the message field.
            try {
                analysis.inputNode?.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            } catch (t: Throwable) {
                // A stale node simply means we have to fall back to the IME connection.
            }

            // 2. Try the accessibility ACTION_SET_TEXT path first.
            try {
                val args = Bundle()
                args.putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    reply
                )
                analysis.inputNode?.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            } catch (t: Throwable) {
                // ignore — the IME path below is the fallback
            }

            // 3. Verify what actually landed in the field before typing twice.
            val verification = ReaderBridge.root()?.let { freshRoot ->
                ConversationParser.findInputField(freshRoot)?.text?.toString().orEmpty()
            }.orEmpty()
            written = verification.contains(reply.take(24).trim()) || verification.trim() == reply.trim()

            if (!written) {
                written = ime?.commitText(reply) == true
            }

            if (!written) {
                // 4. Last resort: re-read the tree, focus the fresh field and type again.
                val freshRoot = ReaderBridge.root()
                val freshInput = ConversationParser.findInputField(freshRoot)
                try {
                    freshInput?.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                } catch (t: Throwable) {
                    // ignore
                }
                written = ime?.commitText(reply) == true
            }

            if (!written) {
                App.log(Strings.get("log_no_input", App.config.language), LogLevel.ERROR)
                App.log(Strings.get("log_text_failed", App.config.language), LogLevel.ERROR)
                App.setStatus(AgentPhase.ERROR, Strings.get("log_text_failed", App.config.language))
                blindUntil = System.currentTimeMillis() + BLIND_AFTER_MS
                return@withLock
            }
            App.log(Strings.get("log_text_written", App.config.language), LogLevel.OK)

            // 5. Give the app 400 ms to swap the microphone for the send button.
            delay(SEND_WAIT_MS)

            // 6. Re-read the tree and press the freshly revealed send button.
            val root = ReaderBridge.root()
            val sendButton = ConversationParser.findSendButton(
                root,
                analysis.screen.inputBounds,
                analysis.screen.isRtl
            )
            var clicked = false
            if (sendButton != null) {
                clicked = try {
                    sendButton.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                } catch (t: Throwable) {
                    false
                }
            }
            if (clicked) {
                App.log(Strings.get("log_send_clicked", App.config.language), LogLevel.OK)
            } else {
                // Fallback: ask the editor to perform the send action.
                val imeSent = ime?.performSendAction() == true
                App.log(
                    Strings.get("log_send_failed", App.config.language) + if (imeSent) " (IME ok)" else "",
                    if (imeSent) LogLevel.WARN else LogLevel.ERROR
                )
            }

            App.bumpSent()
            App.setStatus(AgentPhase.SENDING, Strings.get("phase_sending", App.config.language))
            // 7. Stay blind for two more seconds so the sent bubble settles.
            blindUntil = System.currentTimeMillis() + BLIND_AFTER_MS
        }
    }

    /** Test hook: clears the processed-message memory. */
    fun resetSignatures() {
        lastSignature = null
        handledSignatures.clear()
        contentHash = ""
        nextAllowedAt = 0L
        blindUntil = 0L
    }

    private fun isHandled(signature: String): Boolean = synchronized(handledSignatures) {
        handledSignatures.contains(signature)
    }

    private fun markHandled(signature: String) {
        synchronized(handledSignatures) {
            handledSignatures.addLast(signature)
            while (handledSignatures.size > MAX_SIGNATURES) {
                handledSignatures.removeFirst()
            }
        }
    }

    fun isBlind(): Boolean = System.currentTimeMillis() < blindUntil

    fun cooldownRemainingMs(): Long = (nextAllowedAt - System.currentTimeMillis()).coerceAtLeast(0L)
}
