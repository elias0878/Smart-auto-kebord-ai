package com.sanad.deputy.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** A Gemini model exposed by the current API key. */
data class GeminiModel(
    val name: String,
    val displayName: String,
    val version: String,
    val inputTokenLimit: Int,
    val outputTokenLimit: Int,
    val methods: List<String>
) {
    val shortName: String get() = name.substringAfterLast('/')
    val supportsChat: Boolean get() = methods.any { it.equals("generateContent", true) }
}

/** Result of a generation call. */
sealed interface GeminiOutcome {
    data class Ok(val text: String, val promptTokens: Int = 0, val outputTokens: Int = 0) : GeminiOutcome
    data object RateLimited : GeminiOutcome
    data class InvalidKey(val message: String) : GeminiOutcome
    data class Failed(val message: String, val code: Int = 0) : GeminiOutcome
}

/** Result of the "full key test". */
data class KeyTestResult(
    val ok: Boolean,
    val headline: String,
    val detail: String,
    val models: List<GeminiModel> = emptyList(),
    val generationProbe: String = "",
    val promptTokens: Int = 0,
    val outputTokens: Int = 0,
    val errorCode: Int = 0
)

/**
 * Thin, dependency-free Gemini REST client.
 *
 * - Model names are normalised so `models/models/x` can never be produced.
 * - The request payload is compatible with every Gemini family; if a model rejects
 *   `systemInstruction` the instruction is merged into the user turn and retried once.
 */
object GeminiClient {

    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"
    private const val CONNECT_TIMEOUT = 15_000
    private const val READ_TIMEOUT = 45_000

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    /** Strips any duplicated `models/` prefix. */
    fun cleanModelName(raw: String): String {
        var name = raw.trim()
        while (name.startsWith("models/", ignoreCase = true)) {
            name = name.substring("models/".length).trim()
        }
        while (name.startsWith("/")) name = name.substring(1).trim()
        return name.ifBlank { "gemini-2.5-flash" }
    }

    suspend fun listModels(apiKey: String): Result<List<GeminiModel>> = withContext(Dispatchers.IO) {
        runCatching {
            if (apiKey.isBlank()) throw GeminiException("API_KEY_MISSING", "لم يتم إدخال مفتاح API", 0)
            val url = "$BASE/models?key=${apiKey.urlEncoded()}&pageSize=200"
            val (code, body) = httpGet(url)
            when {
                code == 401 || code == 403 -> throw GeminiException("INVALID_KEY", "المفتاح مرفوض من الخادم (HTTP $code)", code)
                code == 429 -> throw GeminiException("RATE_LIMITED", "تم تجاوز الحصة (HTTP 429)", code)
                code !in 200..299 -> throw GeminiException("HTTP_$code", "فشل HTTP $code: ${body.take(240)}", code)
            }
            parseModels(body)
        }
    }

    /**
     * Generates a reply. Falls back to a merged payload when the model refuses
     * `systemInstruction` (older / specialised models).
     */
    suspend fun generate(
        apiKey: String,
        model: String,
        systemInstruction: String,
        userPrompt: String
    ): GeminiOutcome = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext GeminiOutcome.InvalidKey("لم يتم إدخال مفتاح API")
        val cleanName = cleanModelName(model)
        val url = "$BASE/models/$cleanName:generateContent?key=${apiKey.urlEncoded()}"
        var outcome = post(url, buildPayload(systemInstruction, userPrompt))
        if (outcome is GeminiOutcome.Failed && outcome.code == 400 &&
            outcome.message.contains("systemInstruction", ignoreCase = true)
        ) {
            outcome = post(url, buildPayload("", mergeInstruction(systemInstruction, userPrompt)))
        }
        outcome
    }

    /** Runs a full diagnostic: model discovery + a tiny generation probe. */
    suspend fun testKey(apiKey: String, preferredModel: String): KeyTestResult =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) {
                return@withContext KeyTestResult(
                    ok = false,
                    headline = "لم يتم إدخال مفتاح API",
                    detail = "أدخل المفتاح أولًا ثم أعد الفحص",
                    errorCode = 0
                )
            }
            val modelsResult = listModels(apiKey)
            val models = modelsResult.getOrNull().orEmpty()
            val failure = modelsResult.exceptionOrNull()
            if (failure is GeminiException && failure.code == 429) {
                return@withContext KeyTestResult(
                    ok = false,
                    headline = "الحصة Temporarily exhausted",
                    detail = failure.message,
                    errorCode = 429
                )
            }
            if (failure != null && models.isEmpty()) {
                return@withContext KeyTestResult(
                    ok = false,
                    headline = "المفتاح لا يعمل",
                    detail = failure.message ?: "تعذر الاتصال بخدمة Gemini",
                    errorCode = (failure as? GeminiException)?.code ?: 0
                )
            }
            // Probe generation with the smallest possible request.
            val target = models.firstOrNull { it.shortName.equals(cleanModelName(preferredModel), true) }
                ?: models.firstOrNull { it.supportsChat }
                ?: null
            var probe = ""
            var promptTokens = 0
            var outputTokens = 0
            var ok = true
            var detail = "تم الاتصال بنجاح"
            var errorCode = 0
            if (target == null) {
                ok = false
                detail = "لا يوجد نموذج يدعم generateContent على هذا المفتاح"
            } else {
                when (val probeResult = generate(apiKey, target.name, "You are a test harness.", "Reply with the single word: READY")) {
                    is GeminiOutcome.Ok -> {
                        probe = probeResult.text.trim().take(120)
                        promptTokens = probeResult.promptTokens
                        outputTokens = probeResult.outputTokens
                    }
                    is GeminiOutcome.RateLimited -> {
                        ok = false
                        errorCode = 429
                        detail = "تم تجاوز الحصة أثناء اختبار التوليد (429)"
                    }
                    is GeminiOutcome.InvalidKey -> {
                        ok = false
                        errorCode = 401
                        detail = probeResult.message
                    }
                    is GeminiOutcome.Failed -> {
                        ok = false
                        errorCode = probeResult.code
                        detail = probeResult.message
                    }
                }
            }
            KeyTestResult(
                ok = ok,
                headline = if (ok) "المفتاح يعمل" else "المفتاح لا يعمل",
                detail = detail,
                models = models,
                generationProbe = probe,
                promptTokens = promptTokens,
                outputTokens = outputTokens,
                errorCode = errorCode
            )
        }

    // ---------------------------------------------------------------- internals

    private fun parseModels(body: String): List<GeminiModel> {
        val root = runCatching { json.parseToJsonElement(body).jsonObject }.getOrNull() ?: return emptyList()
        val array: JsonArray = root["models"]?.jsonArray ?: return emptyList()
        return array.mapNotNull { element ->
            val obj = element as? JsonObject ?: return@mapNotNull null
            val name = (obj["name"] as? JsonPrimitive)?.contentOrNull ?: return@mapNotNull null
            GeminiModel(
                name = name,
                displayName = (obj["displayName"] as? JsonPrimitive)?.contentOrNull ?: name.substringAfterLast('/'),
                version = (obj["version"] as? JsonPrimitive)?.contentOrNull.orEmpty(),
                inputTokenLimit = (obj["inputTokenLimit"] as? JsonPrimitive)?.intOrNull ?: 0,
                outputTokenLimit = (obj["outputTokenLimit"] as? JsonPrimitive)?.intOrNull ?: 0,
                methods = (obj["supportedGenerationMethods"] as? JsonArray)
                    ?.mapNotNull { (it as? JsonPrimitive)?.contentOrNull }
                    .orEmpty()
            )
        }.sortedBy { it.name }
    }

    private fun buildPayload(systemInstruction: String, userPrompt: String): String {
        val root = buildJsonObject {
            put(
                "contents",
                buildJsonArray {
                    add(
                        buildJsonObject {
                            put("role", "user")
                            put(
                                "parts",
                                buildJsonArray {
                                    add(buildJsonObject { put("text", userPrompt) })
                                }
                            )
                        }
                    )
                }
            )
            if (systemInstruction.isNotBlank()) {
                put(
                    "systemInstruction",
                    buildJsonObject {
                        put(
                            "parts",
                            buildJsonArray {
                                add(buildJsonObject { put("text", systemInstruction) })
                            }
                        )
                    }
                )
            }
            put(
                "generationConfig",
                buildJsonObject {
                    put("temperature", 0.85)
                    put("topP", 0.95)
                    put("maxOutputTokens", 1024)
                }
            )
        }
        return root.toString()
    }

    private fun mergeInstruction(systemInstruction: String, userPrompt: String): String {
        if (systemInstruction.isBlank()) return userPrompt
        return "$systemInstruction\n\n---\n$userPrompt"
    }

    private fun post(url: String, payload: String): GeminiOutcome {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = CONNECT_TIMEOUT
                readTimeout = READ_TIMEOUT
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
            }
            connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val body = connection.readBody(code)
            when {
                code == 401 || code == 403 -> GeminiOutcome.InvalidKey("المفتاح غير صالح أو لا يملك صلاحية (HTTP $code)")
                code == 429 -> GeminiOutcome.RateLimited
                code !in 200..299 -> GeminiOutcome.Failed(extractError(body, code), code)
                else -> parseGeneration(body)
            }
        } catch (t: Throwable) {
            GeminiOutcome.Failed(t.message ?: "تعذر الاتصال بالإنترنت", 0)
        } finally {
            runCatching { connection?.disconnect() }
        }
    }

    private fun httpGet(url: String): Pair<Int, String> {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = CONNECT_TIMEOUT
                readTimeout = READ_TIMEOUT
                setRequestProperty("Accept", "application/json")
            }
            val code = connection.responseCode
            code to connection.readBody(code)
        } finally {
            runCatching { connection?.disconnect() }
        }
    }

    private fun parseGeneration(body: String): GeminiOutcome {
        val root = runCatching { json.parseToJsonElement(body).jsonObject }.getOrNull()
            ?: return GeminiOutcome.Failed("استجابة غير مفهومة من الخادم", 200)
        val blocked = (root["promptFeedback"] as? JsonObject)?.get("blockReason") as? JsonPrimitive
        if (blocked != null && blocked.contentOrNull != null) {
            return GeminiOutcome.Failed("تم حجب الطلب (${blocked.contentOrNull})", 200)
        }
        val candidates = root["candidates"]?.jsonArray
        val first = candidates?.firstOrNull() as? JsonObject
        val parts = first?.get("content")?.jsonObject?.get("parts")?.jsonArray
        val text = parts
            ?.mapNotNull { part ->
                (part as? JsonObject)?.get("text")?.let { (it as? JsonPrimitive)?.contentOrNull }
            }
            ?.joinToString(separator = "")
            .orEmpty()
        if (text.isBlank()) {
            val finish = (first?.get("finishReason") as? JsonPrimitive)?.contentOrNull
            return GeminiOutcome.Failed("لم يُرجع النموذج أي نص${if (finish != null) " ($finish)" else ""}", 200)
        }
        val usage = root["usageMetadata"] as? JsonObject
        val promptTokens = (usage?.get("promptTokenCount") as? JsonPrimitive)?.intOrNull ?: 0
        val outputTokens = (usage?.get("candidatesTokenCount") as? JsonPrimitive)?.intOrNull ?: 0
        return GeminiOutcome.Ok(text, promptTokens, outputTokens)
    }

    private fun extractError(body: String, code: Int): String {
        val parsed = runCatching {
            val root = json.parseToJsonElement(body).jsonObject
            val error = root["error"] as? JsonObject
            val message = (error?.get("message") as? JsonPrimitive)?.contentOrNull
            val status = (error?.get("status") as? JsonPrimitive)?.contentOrNull
            listOfNotNull(status, message).joinToString(": ")
        }.getOrNull()
        return parsed?.takeIf { it.isNotBlank() } ?: "HTTP $code"
    }

    private fun HttpURLConnection.readBody(code: Int): String {
        return try {
            val stream = if (code in 200..299) inputStream else errorStream
            stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        } catch (t: Throwable) {
            ""
        }
    }

    private fun String.urlEncoded(): String = URLEncoder.encode(this.trim(), "UTF-8")

    class GeminiException(
        val tag: String,
        override val message: String,
        val code: Int
    ) : Exception(message)
}
