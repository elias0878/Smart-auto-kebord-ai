package com.sanad.deputy.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.ErrorOutline
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.Keyboard
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.launch
import com.sanad.deputy.core.AgentPhase
import com.sanad.deputy.core.App
import com.sanad.deputy.core.LogLevel
import com.sanad.deputy.core.Strings
import com.sanad.deputy.core.SystemStatus
import com.sanad.deputy.core.t
import com.sanad.deputy.engine.AutonomousAgent
import com.sanad.deputy.ui.components.ChecklistRow
import com.sanad.deputy.ui.components.Pill
import com.sanad.deputy.ui.components.PulsingDot
import com.sanad.deputy.ui.components.SectionCard
import com.sanad.deputy.ui.components.StatTile
import com.sanad.deputy.ui.theme.BrandGradientEnd
import com.sanad.deputy.ui.theme.BrandGradientStart
import com.sanad.deputy.ui.theme.BrandGold
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen() {
    val context = LocalContext.current
    val status by App.status.collectAsState()
    val config by App.configState.collectAsState()
    val logs by App.logs.collectAsState()
    val screen by App.lastScreen.collectAsState()
    val currentApp by App.currentApp.collectAsState()
    val sentCount by App.sentCount.collectAsState()
    val requestCount by App.requestCount.collectAsState()
    val cooldownUntil by App.cooldownUntil.collectAsState()
    val pendingReply by App.lastReply.collectAsState()

    var readerEnabled by remember { mutableStateOf(false) }
    var imeSelected by remember { mutableStateOf(false) }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                readerEnabled = SystemStatus.accessibilityEnabled(context)
                imeSelected = SystemStatus.imeSelected(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        readerEnabled = SystemStatus.accessibilityEnabled(context)
        imeSelected = SystemStatus.imeSelected(context)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val cooldownSeconds = ((cooldownUntil - System.currentTimeMillis()) / 1000L).coerceAtLeast(0L)
    val copiedLabel = t("copied")

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ------------------------------------------------------------ hero
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(26.dp))
                    .background(
                        Brush.linearGradient(listOf(BrandGradientStart, BrandGradientEnd))
                    )
                    .padding(20.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PulsingDot(color = BrandGold)
                        Spacer(modifier = Modifier.width(9.dp))
                        Text(
                            text = t("home_hero_title"),
                            style = MaterialTheme.typography.titleSmall,
                            color = BrandGold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = t("app_title"),
                        style = MaterialTheme.typography.headlineSmall,
                        color = androidx.compose.ui.graphics.Color.White
                    )
                    Text(
                        text = t("home_hero_sub"),
                        style = MaterialTheme.typography.bodySmall,
                        color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.82f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = statusIcon(status.phase),
                            contentDescription = null,
                            tint = androidx.compose.ui.graphics.Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = phaseLabel(status.phase),
                            style = MaterialTheme.typography.titleSmall,
                            color = androidx.compose.ui.graphics.Color.White
                        )
                    }
                    if (status.detail.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = status.detail,
                            style = MaterialTheme.typography.bodySmall,
                            color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.75f)
                        )
                    }
                }
            }
        }

        // ---------------------------------------------------- current chat
        item {
            SectionCard(
                title = t("home_current_chat"),
                icon = Icons.Outlined.Chat
            ) {
                if (screen == null || screen?.messages.isNullOrEmpty()) {
                    Text(
                        text = t("home_no_chat"),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    val parsed = screen
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = parsed?.contactName ?: t("none"),
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = currentApp ?: t("none"),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Pill(
                            text = if (parsed?.isRtl == true) "RTL" else "LTR",
                            container = MaterialTheme.colorScheme.tertiaryContainer,
                            content = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                    }
                    parsed?.lastMessage?.let { last ->
                        Spacer(modifier = Modifier.height(12.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                .padding(12.dp)
                        ) {
                            Column {
                                Text(
                                    text = if (last.isMine) t("home_you") else t("home_them"),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(text = last.text, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }
        }

        // ------------------------------------------------------- checklist
        item {
            SectionCard(
                title = t("home_setup_title"),
                icon = Icons.Outlined.Security
            ) {
                ChecklistRow(
                    title = t("home_setup_accessibility"),
                    description = t("home_setup_accessibility_desc"),
                    done = readerEnabled,
                    actionLabel = t("enable"),
                    onAction = {
                        runCatching {
                            context.startActivity(
                                Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    }
                )
                ChecklistRow(
                    title = t("home_setup_ime"),
                    description = t("home_setup_ime_desc"),
                    done = imeSelected,
                    actionLabel = t("enable"),
                    onAction = {
                        runCatching {
                            context.startActivity(
                                Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    }
                )
                ChecklistRow(
                    title = t("home_setup_key"),
                    description = t("home_setup_key_desc"),
                    done = config.apiKey.isNotBlank(),
                    actionLabel = t("tab_models"),
                    onAction = { }
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = t("home_ime_note"),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // --------------------------------------------------------- controls
        item {
            SectionCard(
                title = t("home_control_title"),
                icon = Icons.Outlined.Timer
            ) {
                ToggleRow(
                    title = t("home_auto_pilot"),
                    description = t("home_auto_pilot_desc"),
                    checked = config.autoPilot,
                    onChange = { enabled ->
                        App.scope.launch {
                            App.store?.setAutoPilot(enabled)
                        }
                    }
                )
                ToggleRow(
                    title = t("home_auto_send"),
                    description = t("home_auto_send_desc"),
                    checked = config.autoSend,
                    onChange = { enabled ->
                        App.scope.launch {
                            App.store?.setAutoSend(enabled)
                        }
                    }
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "${t("home_cooldown")} · ${config.cooldownSeconds}${t("seconds_short")}",
                    style = MaterialTheme.typography.titleSmall
                )
                Text(
                    text = t("home_cooldown_desc"),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Slider(
                    value = config.cooldownSeconds.toFloat(),
                    onValueChange = { value ->
                        val seconds = value.toInt()
                        App.scope.launch { App.store?.setCooldown(seconds) }
                    },
                    valueRange = 0f..60f,
                    steps = 11
                )
            }
        }

        // ------------------------------------------------------- force reply
        item {
            Button(
                onClick = { AutonomousAgent.forceReply() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(Icons.Outlined.Bolt, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = t("home_force_reply"),
                    style = MaterialTheme.typography.titleMedium
                )
            }
        }

        // ------------------------------------------------------ pending reply
        if (!pendingReply.isNullOrBlank() && !config.autoSend) {
            val reply = pendingReply ?: ""
            item {
                SectionCard(
                    title = t("home_pending_reply"),
                    icon = Icons.Outlined.Bolt
                ) {
                    Text(text = reply, style = MaterialTheme.typography.bodyLarge)
                    Spacer(modifier = Modifier.height(10.dp))
                    FilledTonalButton(
                        onClick = {
                            val clipboard = context.getSystemService(
                                android.content.Context.CLIPBOARD_SERVICE
                            ) as? android.content.ClipboardManager
                            val clip = android.content.ClipData.newPlainText("Sanad", reply)
                            clipboard?.setPrimaryClip(clip)
                            App.log(copiedLabel, LogLevel.OK)
                        },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(t("copy"))
                    }
                }
            }
        }

        // ----------------------------------------------------------- stats
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile(
                    value = requestCount.toString(),
                    label = t("home_stat_requests"),
                    modifier = Modifier.weight(1f)
                )
                StatTile(
                    value = sentCount.toString(),
                    label = t("home_stat_sent"),
                    modifier = Modifier.weight(1f),
                    accent = BrandGold
                )
                StatTile(
                    value = "${cooldownSeconds}${t("seconds_short")}",
                    label = t("home_stat_cooldown"),
                    modifier = Modifier.weight(1f),
                    accent = MaterialTheme.colorScheme.tertiary
                )
            }
        }

        // ------------------------------------------------------------- log
        item {
            SectionCard(
                title = t("home_activity"),
                icon = Icons.Outlined.CheckCircle
            ) {
                if (logs.isEmpty()) {
                    Text(
                        text = t("home_no_activity"),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    logs.asReversed().take(12).forEach { entry ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Box(
                                modifier = Modifier
                                    .padding(top = 5.dp)
                                    .size(7.dp)
                                    .background(logColor(entry.level), CircleShape)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = entry.message,
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    text = timeFormat.format(Date(entry.time)),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ToggleRow(
    title: String,
    description: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.titleSmall)
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun phaseLabel(phase: AgentPhase): String = when (phase) {
    AgentPhase.DISABLED -> t("phase_disabled")
    AgentPhase.IDLE -> t("phase_idle")
    AgentPhase.WATCHING -> t("phase_watching")
    AgentPhase.THINKING -> t("phase_thinking")
    AgentPhase.WRITING -> t("phase_writing")
    AgentPhase.SENDING -> t("phase_sending")
    AgentPhase.COOLDOWN -> t("phase_cooldown")
    AgentPhase.ERROR -> t("phase_error")
}

private fun statusIcon(phase: AgentPhase): ImageVector = when (phase) {
    AgentPhase.ERROR -> Icons.Outlined.ErrorOutline
    AgentPhase.COOLDOWN -> Icons.Outlined.Timer
    AgentPhase.THINKING, AgentPhase.WRITING, AgentPhase.SENDING -> Icons.Outlined.Bolt
    AgentPhase.DISABLED -> Icons.Outlined.Keyboard
    else -> Icons.Outlined.Security
}

@Composable
private fun logColor(level: LogLevel) = when (level) {
    LogLevel.INFO -> MaterialTheme.colorScheme.primary
    LogLevel.OK -> MaterialTheme.colorScheme.tertiary
    LogLevel.WARN -> BrandGold
    LogLevel.ERROR -> MaterialTheme.colorScheme.error
}

private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
