package com.sanad.deputy.core

import androidx.compose.runtime.Composable

/** A bilingual string pair. Arabic is the source of truth, English is the mirror. */
data class L10n(val ar: String, val en: String)

/**
 * Central bilingual catalogue. Switching [AppLanguage] flips the entire UI
 * (and the IME strip) instantly without recreating the activity.
 */
object Strings {

    private val map: Map<String, L10n> = mapOf(
        // ---- identity -------------------------------------------------------
        "app_title" to L10n("سَنَد", "Sanad"),
        "app_tagline" to L10n("وكيل المحادثات الذي يكتب ويرسل نيابةً عنك", "The chat deputy that writes and sends for you"),
        "app_name_long" to L10n("سَنَد — وكيلك الذكي", "Sanad — Your AI Deputy"),

        // ---- navigation -----------------------------------------------------
        "tab_home" to L10n("الرئيسية", "Home"),
        "tab_live" to L10n("المحادثة", "Live"),
        "tab_models" to L10n("النماذج", "Models"),
        "tab_settings" to L10n("الإعدادات", "Settings"),

        // ---- generic --------------------------------------------------------
        "ok" to L10n("حسنًا", "OK"),
        "cancel" to L10n("إلغاء", "Cancel"),
        "save" to L10n("حفظ", "Save"),
        "saved" to L10n("تم الحفظ", "Saved"),
        "close" to L10n("إغلاق", "Close"),
        "copy" to L10n("نسخ", "Copy"),
        "copied" to L10n("تم النسخ", "Copied"),
        "refresh" to L10n("تحديث", "Refresh"),
        "retry" to L10n("إعادة المحاولة", "Retry"),
        "enable" to L10n("تفعيل", "Enable"),
        "disable" to L10n("تعطيل", "Disable"),
        "yes" to L10n("نعم", "Yes"),
        "no" to L10n("لا", "No"),
        "error" to L10n("خطأ", "Error"),
        "loading" to L10n("جارٍ التحميل…", "Loading…"),
        "none" to L10n("غير متوفر", "Unavailable"),
        "open_settings" to L10n("فتح الإعدادات", "Open settings"),
        "seconds_short" to L10n("ث", "s"),
        "lang_toggle" to L10n("ع / EN", "ع / EN"),
        "ime_force" to L10n("⚡ رد فوري", "⚡ Reply"),
        "ime_cooldown" to L10n("تبريد", "cooldown"),

        // ---- phases ---------------------------------------------------------
        "phase_disabled" to L10n("الوضع التلقائي مُعطَّل", "Auto-pilot is off"),
        "phase_idle" to L10n("جاهز للمراقبة", "Standing by"),
        "phase_watching" to L10n("يراقب المحادثة", "Watching the chat"),
        "phase_thinking" to L10n("يفكّر في الرد", "Thinking of a reply"),
        "phase_writing" to L10n("يكتب الرد", "Writing the reply"),
        "phase_sending" to L10n("يُرسل الرد", "Sending the reply"),
        "phase_cooldown" to L10n("تبريد مؤقت", "Cooling down"),
        "phase_error" to L10n("حدث خطأ", "Something went wrong"),

        // ---- home -----------------------------------------------------------
        "home_hero_title" to L10n("الوكيل الذكي", "Autonomous agent"),
        "home_hero_sub" to L10n("يراقب محادثة واتساب ويكتب ويرد تلقائيًا", "Watches your chat and replies on its own"),
        "home_current_chat" to L10n("المحادثة الحالية", "Current chat"),
        "home_no_chat" to L10n("لا توجد محادثة نشطة", "No active chat"),
        "home_contact" to L10n("المحادث", "Contact"),
        "home_app" to L10n("التطبيق", "App"),
        "home_last_message" to L10n("آخر رسالة", "Last message"),
        "home_you" to L10n("أنت", "You"),
        "home_them" to L10n("الطرف الآخر", "Them"),
        "home_setup_title" to L10n("خطوات التفعيل", "Setup checklist"),
        "home_setup_accessibility" to L10n("خدمة الإدراك البصري", "Visual reader service"),
        "home_setup_accessibility_desc" to L10n("lets Sanad read the conversation", "lets Sanad read the conversation"),
        "home_setup_ime" to L10n("لوحة مفاتيح سَنَد", "Sanad keyboard"),
        "home_setup_ime_desc" to L10n("lets Sanad type and send for you", "lets Sanad type and send for you"),
        "home_setup_key" to L10n("مفتاح Gemini API", "Gemini API key"),
        "home_setup_key_desc" to L10n("required for generating replies", "required for generating replies"),
        "home_setup_done" to L10n("مُفعَّل", "Enabled"),
        "home_setup_pending" to L10n("يحتاج تفعيل", "Needs setup"),
        "home_control_title" to L10n("التحكم", "Controls"),
        "home_auto_pilot" to L10n("الوضع التلقائي", "Auto-pilot"),
        "home_auto_pilot_desc" to L10n("يقرأ ويرد من تلقاء نفسه", "Reads and replies by itself"),
        "home_auto_send" to L10n("الإرسال التلقائي", "Auto send"),
        "home_auto_send_desc" to L10n("يضغط زر الإرسال تلقائيًا", "Clicks the send button for you"),
        "home_cooldown" to L10n("أمان بين الطلبات", "Safe request gap"),
        "home_cooldown_desc" to L10n("أقل ثانية واحدة لتفادي حظر المفتاح", "Minimum gap to protect the key"),
        "home_force_reply" to L10n("رد فوري الآن", "Force reply now"),
        "home_force_reply_desc" to L10n("يتخطى كل الانتظارات ويرد على المحادثة المفتوحة", "Skips every wait and answers the open chat"),
        "home_activity" to L10n("سجل النشاط", "Activity log"),
        "home_no_activity" to L10n("لا توجد أحداث بعد", "No events yet"),
        "home_stats" to L10n("الإحصاءات", "Statistics"),
        "home_stat_requests" to L10n("طلبات", "Requests"),
        "home_stat_sent" to L10n("رسائل مُرسَلة", "Replies sent"),
        "home_stat_cooldown" to L10n("مدة التبريد", "Cooldown"),
        "home_pending_reply" to L10n("رد جاهز للنسخ", "Reply ready to copy"),
        "home_ime_note" to L10n("لوحة المفاتيح مخصّصة للوكيل — يمكنك تعطيلها من إعدادات الأندرويد في أي وقت", "The keyboard is agent-only — disable it from Android settings anytime"),

        // ---- live -----------------------------------------------------------
        "live_title" to L10n("الإدراك البصري المباشر", "Live visual perception"),
        "live_empty" to L10n("في انتظار قراءة الشاشة…", "Waiting for the screen…"),
        "live_messages" to L10n("الرسائل المكتشفة", "Detected messages"),
        "live_typing" to L10n("الطرف الآخر يكتب…", "They are typing…"),
        "live_typing_yes" to L10n("مكتشف: يكتب الآن", "Detected: typing"),
        "live_typing_no" to L10n("لا يوجد مؤشر كتابة", "No typing indicator"),
        "live_input_found" to L10n("حقل الإدخال", "Input field"),
        "live_input_yes" to L10n("تم العثور عليه", "Found"),
        "live_input_no" to L10n("غير موجود", "Missing"),
        "live_send_button" to L10n("زر الإرسال", "Send button"),
        "live_send_yes" to L10n("متاح للضغط", "Ready to click"),
        "live_send_no" to L10n("غير موجود بعد", "Not found yet"),
        "live_layout" to L10n("اتجاه الواجهة", "Interface direction"),
        "live_rtl" to L10n("من اليمين لليسار (RTL)", "Right to left (RTL)"),
        "live_ltr" to L10n("من اليسار لليمين (LTR)", "Left to right (LTR)"),
        "live_nodes" to L10n("عقد الشجرة المفحوصة", "Nodes inspected"),
        "live_updated" to L10n("آخر تحديث", "Last update"),
        "live_mine_count" to L10n("رسائلي", "Mine"),
        "live_theirs_count" to L10n("رسائل الطرف الآخر", "Theirs"),
        "live_confidence" to L10n("دقة التمييز", "Detection accuracy"),
        "live_hint" to L10n("يقرأ الوكيل آخر فقاعة فوق حقل الكتابة ليعرف إن كان يجب أن يصمت", "The agent reads the last bubble above the input to decide whether to stay silent"),

        // ---- models ---------------------------------------------------------
        "models_title" to L10n("مفتاح API والنماذج", "API key & models"),
        "models_api_key" to L10n("مفتاح Gemini API", "Gemini API key"),
        "models_api_key_hint" to L10n("AIza…", "AIza…"),
        "models_show" to L10n("إظهار", "Show"),
        "models_hide" to L10n("إخفاء", "Hide"),
        "models_test" to L10n("اختبار وفحص شامل", "Full key test"),
        "models_testing" to L10n("جارٍ الفحص…", "Testing…"),
        "models_key_ok" to L10n("المفتاح يعمل", "The key works"),
        "models_key_bad" to L10n("المفتاح لا يعمل", "The key does not work"),
        "models_key_models" to L10n("عدد النماذج المتاحة", "Available models"),
        "models_key_generate" to L10n("اختبار التوليد", "Generation test"),
        "models_key_generate_ok" to L10n("الاستجابة: ", "Response: "),
        "models_key_limits" to L10n("حدود المفتاح", "Key limits"),
        "models_key_limits_body" to L10n("الحد الأقصى للإدخال: %1\$d رمز — الحد الأقصى للمخرجات: %2\$d رمز", "Max input: %1\$d tokens — Max output: %2\$d tokens"),
        "models_key_caps" to L10n("القدرات", "Capabilities"),
        "models_list" to L10n("النماذج المتاحة في مفتاحك", "Models available on your key"),
        "models_list_empty" to L10n("لم يتم العثور على نماذج — أدخل مفتاحًا صحيحًا", "No models found — check the key"),
        "models_selected" to L10n("النموذج الحالي", "Active model"),
        "models_use" to L10n("استخدام", "Use"),
        "models_in" to L10n("إدخال", "Input"),
        "models_out" to L10n("إخراج", "Output"),
        "models_methods" to L10n("الطرق المدعومة", "Supported methods"),
        "models_no_key" to L10n("أدخل المفتاح أولًا", "Enter a key first"),
        "models_key_saved" to L10n("تم حفظ المفتاح", "Key saved"),
        "models_version" to L10n("الإصدار", "Version"),
        "models_display" to L10n("الاسم المعروض", "Display name"),

        // ---- settings -------------------------------------------------------
        "settings_title" to L10n("الشخصية والذاكرة", "Persona & memory"),
        "settings_persona" to L10n("شخصية الوكيل", "Agent persona"),
        "settings_persona_hint" to L10n("الوصف، اللهجة، أسلوب الرد…", "Description, dialect, reply style…"),
        "settings_persona_placeholder" to L10n("مثال: أنت مهندس برمجيات، تتحدث بلهجة خليجية مهنية، ردودك قصيرة وواضحة.", "Example: you are a software engineer, professional tone, short and clear replies."),
        "settings_presets" to L10n("قوالب جاهزة", "Presets"),
        "settings_memory" to L10n("الذاكرة الكبرى", "Deep memory"),
        "settings_memory_hint" to L10n("كل ما يجب أن يعرفه الوكيل عنك", "Everything the agent must know about you"),
        "settings_memory_placeholder" to L10n("اسمك، عملك، أسلوبك، projecтs… أسلوبLife…", "Your name, work, style, projects…"),
        "settings_behavior" to L10n("سلوك الوكيل", "Agent behaviour"),
        "settings_language" to L10n("لغة التطبيق", "App language"),
        "settings_signature_lock" to L10n("قفل بصمة الرسالة", "Message signature lock"),
        "settings_signature_lock_desc" to L10n("يمنع تكرار الرد على نفس الرسالة", "Prevents replying twice to the same message"),
        "settings_stability" to L10n("مدة استقرار الشاشة", "Screen settle time"),
        "settings_stability_desc" to L10n("ينتظر قبل الرد حتى تتوقف الكتابة", "Waits until typing stops"),
        "settings_reset" to L10n("مسح الذاكرة", "Clear memory"),
        "settings_reset_done" to L10n("تم مسح الذاكرة", "Memory cleared"),
        "settings_characters" to L10n("%1\$d حرف", "%1\$d chars"),
        "settings_about" to L10n("عن التطبيق", "About"),
        "settings_about_body" to L10n("سَنَد وكيل يعمل محليًا على جهازك: يقرأ شجرة الشاشة عبر خدمة الوصول، ويكتب ويرسل عبر لوحة مفاتيحه الخاصة، ولا يخرج أي بيان إلى السحابة إلا نص المحادثة المرسل إلى Gemini.", "Sanad runs entirely on-device: it reads the screen tree through the accessibility service, types and sends through its own keyboard, and the only data leaving the device is the conversation text sent to Gemini."),
        "settings_about_version" to L10n("الإصدار %1\$s", "Version %1\$s"),
        "settings_persona_empty" to L10n("لم تُحدَّد شخصية — سيستخدم الوكيل أسلوبًا محايدًا", "No persona set — the agent stays neutral"),
        "settings_memory_empty" to L10n("لا توجد ذاكرة محفوظة", "No memory stored"),

        // ---- logs -----------------------------------------------------------
        "log_service_ready" to L10n("تم تفعيل خدمة الإدراك البصري", "Visual reader service connected"),
        "log_no_root" to L10n("تعذّر الوصول إلى شجرة الشاشة", "Could not reach the screen tree"),
        "log_parse_failed" to L10n("فشل تحليل الشاشة", "Screen parsing failed"),
        "log_no_messages" to L10n("لا توجد رسائل صالحة في الشاشة", "No valid messages on screen"),
        "log_silent" to L10n("آخر رسالة منك — التزام الصمت", "Last message is yours — staying silent"),
        "log_wait_stability" to L10n("بانتظار استقرار المحادثة", "Waiting for the chat to settle"),
        "log_typing" to L10n("الطرف الآخر يكتب — انتظار", "They are typing — holding"),
        "log_cooldown" to L10n("تبريد نشط لتفادي الحظر", "Cooling down to protect the key"),
        "log_request_start" to L10n("إرسال طلب إلى Gemini", "Calling Gemini"),
        "log_request_ok" to L10n("تم توليد الرد", "Reply generated"),
        "log_request_failed" to L10n("فشل الطلب", "Request failed"),
        "log_rate_limited" to L10n("تم تجاوز الحصة (429) — تبريد 30 ثانية", "Quota exceeded (429) — 30s cooldown"),
        "log_invalid_key" to L10n("المفتاح غير صالح", "Invalid API key"),
        "log_text_written" to L10n("تم حقن الرد في حقل الكتابة", "Reply injected into the input field"),
        "log_text_failed" to L10n("تعذّر الكتابة في الحقل", "Could not type into the field"),
        "log_send_clicked" to L10n("تم الضغط على زر الإرسال", "Send button clicked"),
        "log_send_failed" to L10n("لم يُعثر على زر الإرسال — استُخدم IME_ACTION_SEND", "Send button not found — used IME_ACTION_SEND"),
        "log_no_input" to L10n("لا يوجد حقل إدخال في الشاشة", "No input field on screen"),
        "log_inflight" to L10n("طلب جارٍ بالفعل — تم التخطي", "A request is already running — skipped"),
        "log_signature_skip" to L10n("نفس الرسالة تمت معالجتها — لا تكرار", "Same message already handled"),
        "log_blind" to L10n("إيقاف القراءة أثناء التنفيذ الذاتي", "Reader paused during self-action"),
        "log_force" to L10n("رد فوري بطلب من المستخدم", "Force reply requested by the user"),
        "log_no_api_key" to L10n("لا يوجد مفتاح API — تعذّر التوليد", "No API key — generation skipped"),
        "log_empty_reply" to L10n("أعاد النموذج ردًا فارغًا", "The model returned an empty reply"),
        "log_fallback" to L10n("النموذج لا يدعم تعليمات النظام — تم دمجها", "Model rejected system instructions — merged"),
        "log_model_cleaned" to L10n("تم تنظيف اسم النموذج: %1\$s", "Model name normalised: %1\$s")
    )

    fun get(key: String, lang: AppLanguage): String {
        val entry = map[key] ?: return key
        return if (lang == AppLanguage.AR) entry.ar else entry.en
    }

    fun has(key: String): Boolean = map.containsKey(key)
}

/** Composable shortcut for the active language. */
@Composable
fun t(key: String): String = Strings.get(key, LocalAppLanguage.current)
