package com.sanad.deputy.core

import android.content.Context
import android.provider.Settings

/** Queries the system for the two privileged components Sanad needs. */
object SystemStatus {

    private const val READER = "com.sanad.deputy/com.sanad.deputy.service.ScreenReaderService"
    private const val IME = "com.sanad.deputy/com.sanad.deputy.service.AgentImeService"

    fun accessibilityEnabled(context: Context): Boolean {
        val enabled = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any {
            it.equals(READER, ignoreCase = true) || it.contains("com.sanad.deputy", ignoreCase = true)
        }
    }

    fun imeSelected(context: Context): Boolean {
        val current = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.DEFAULT_INPUT_METHOD
        ) ?: return false
        return current.contains("com.sanad.deputy", ignoreCase = true)
    }

    fun imeListed(context: Context): Boolean {
        val list = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_INPUT_METHODS
        ) ?: return false
        return list.contains("com.sanad.deputy", ignoreCase = true)
    }
}
