package com.sanad.deputy.core

import android.content.Context
import androidx.compose.runtime.staticCompositionLocalOf
import com.sanad.deputy.data.ConfigStore
import com.sanad.deputy.data.ParsedScreen
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Supported UI languages. Arabic is the primary experience. */
enum class AppLanguage(val code: String) {
    AR("ar"),
    EN("en")
}

/** CompositionLocal carrying the active language so every string flips instantly. */
val LocalAppLanguage = staticCompositionLocalOf { AppLanguage.AR }

/** Runtime configuration, persisted in DataStore and mirrored in memory for services. */
data class AppConfig(
    val apiKey: String = "",
    val model: String = "gemini-2.5-flash",
    val persona: String = "",
    val memory: String = "",
    val language: AppLanguage = AppLanguage.AR,
    val autoPilot: Boolean = true,
    val autoSend: Boolean = true,
    val cooldownSeconds: Int = 8,
    val signatureLock: Boolean = true,
    val stabilitySeconds: Int = 2,
)

/** Coarse state machine of the autonomous agent. */
enum class AgentPhase {
    DISABLED,
    IDLE,
    WATCHING,
    THINKING,
    WRITING,
    SENDING,
    COOLDOWN,
    ERROR
}

data class AgentStatus(
    val phase: AgentPhase = AgentPhase.IDLE,
    val detail: String = "",
    val at: Long = System.currentTimeMillis()
)

enum class LogLevel { INFO, OK, WARN, ERROR }

data class LogEntry(
    val id: Long,
    val time: Long,
    val message: String,
    val level: LogLevel
)

/**
 * Process-wide singleton shared by the UI, the accessibility reader and the IME.
 * Everything here is thread safe: the services run on background threads while the
 * UI collects the exposed StateFlows on the main thread.
 */
object App {

    const val TAG = "Sanad"

    @Volatile
    var config: AppConfig = AppConfig()

    @Volatile
    var store: ConfigStore? = null

    /** Application context, used for package look-ups from services. */
    @Volatile
    var appContext: Context? = null

    /** Last reply produced by the model when auto-send is disabled. */
    private val _lastReply = MutableStateFlow<String?>(null)
    val lastReply: StateFlow<String?> = _lastReply.asStateFlow()

    private val _config = MutableStateFlow(AppConfig())
    val configState: StateFlow<AppConfig> = _config.asStateFlow()

    private val _status = MutableStateFlow(AgentStatus())
    val status: StateFlow<AgentStatus> = _status.asStateFlow()

    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

    private val _lastScreen = MutableStateFlow<ParsedScreen?>(null)
    val lastScreen: StateFlow<ParsedScreen?> = _lastScreen.asStateFlow()

    private val _currentApp = MutableStateFlow<String?>(null)
    val currentApp: StateFlow<String?> = _currentApp.asStateFlow()

    private val _cooldownUntil = MutableStateFlow(0L)
    val cooldownUntil: StateFlow<Long> = _cooldownUntil.asStateFlow()

    private val _sentCount = MutableStateFlow(0)
    val sentCount: StateFlow<Int> = _sentCount.asStateFlow()

    private val _requestCount = MutableStateFlow(0)
    val requestCount: StateFlow<Int> = _requestCount.asStateFlow()

    private var logId = 0L
    private var started = false

    /** Shared scope: SupervisorJob keeps one failure from cancelling the whole agent. */
    val scope: CoroutineScope = CoroutineScope(
        SupervisorJob() + Dispatchers.Default + CoroutineExceptionHandler { _, throwable ->
            log(
                "خطأ داخلي: ${throwable.javaClass.simpleName} — ${throwable.message}",
                LogLevel.ERROR
            )
            setStatus(AgentPhase.ERROR, throwable.message ?: "خطأ غير معروف")
        }
    )

    @Synchronized
    fun init(context: Context) {
        if (started) return
        started = true
        val appContext = context.applicationContext
        val created = ConfigStore(appContext)
        store = created
        this.appContext = appContext
        scope.launch {
            created.configFlow.collect { cfg ->
                config = cfg
                _config.value = cfg
            }
        }
    }

    fun log(message: String, level: LogLevel = LogLevel.INFO) {
        val entry = LogEntry(++logId, System.currentTimeMillis(), message, level)
        _logs.value = (_logs.value + entry).takeLast(250)
    }

    fun setStatus(phase: AgentPhase, detail: String = "") {
        _status.value = AgentStatus(phase, detail)
    }

    fun setLastScreen(screen: ParsedScreen?) {
        _lastScreen.value = screen
    }

    fun setCurrentApp(pkg: String?) {
        _currentApp.value = pkg
    }

    fun setLastReply(reply: String?) {
        _lastReply.value = reply
    }

    fun setCooldown(until: Long) {
        _cooldownUntil.value = until
    }

    fun bumpSent() {
        _sentCount.value = _sentCount.value + 1
    }

    fun bumpRequest() {
        _requestCount.value = _requestCount.value + 1
    }
}
