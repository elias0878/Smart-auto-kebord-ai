package com.sanad.deputy.service

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import com.sanad.deputy.core.AgentPhase
import com.sanad.deputy.core.App
import com.sanad.deputy.core.LogLevel
import com.sanad.deputy.core.Strings
import com.sanad.deputy.engine.AutonomousAgent

/**
 * The "eyes" of the agent.
 *
 * Critical stability rule: every event that originates from our own package — the IME
 * strip, our status bar refresh, our own activity — is ignored. Without this guard the
 * keyboard's own updates would trigger a fresh screen read, which would trigger another
 * update, and the app would spin in an endless loop until it crashed.
 */
class ScreenReaderService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        ReaderBridge.service = this
        App.init(applicationContext)
        App.log(Strings.get("log_service_ready", App.config.language), LogLevel.OK)
        App.setStatus(AgentPhase.IDLE, Strings.get("phase_idle", App.config.language))
        AutonomousAgent.start()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val ev = event ?: return
        val eventPackage = try {
            ev.packageName?.toString()
        } catch (t: Throwable) {
            null
        } ?: return

        // ---- SELF-PACKAGE EVENT IGNORE -------------------------------------
        if (eventPackage == packageName) return
        val sourcePackage = try {
            ev.source?.packageName?.toString()
        } catch (t: Throwable) {
            null
        }
        if (sourcePackage == packageName) return
        // ---------------------------------------------------------------

        when (ev.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED,
            AccessibilityEvent.TYPE_WINDOWS_CHANGED -> Unit

            else -> return
        }

        // Ignore system UI noise, but keep the real target app.
        if (eventPackage == "com.android.systemui") return

        AutonomousAgent.signal(eventPackage)
    }

    override fun onInterrupt() {
        App.log("reader interrupted", LogLevel.WARN)
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        ReaderBridge.service = null
        App.setStatus(AgentPhase.DISABLED, Strings.get("phase_disabled", App.config.language))
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        ReaderBridge.service = null
        super.onDestroy()
    }
}
