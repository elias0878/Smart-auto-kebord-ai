package com.agon.app.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.AtomicFile
import android.util.Base64
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

@Serializable data class Memory(val id: String = UUID.randomUUID().toString(), val title: String, val body: String, val category: String = "personal")
@Serializable data class ModelInfo(val name: String, val displayName: String, val inputLimit: Int = 0, val outputLimit: Int = 0, val description: String = "")
@Serializable data class ActivityEntry(val at: Long = System.currentTimeMillis(), val ar: String, val en: String, val kind: String = "info")
@Serializable data class AppData(
    val arabic: Boolean = true,
    val dark: Boolean = false,
    val key: String = "",
    val model: String = "",
    val models: List<ModelInfo> = emptyList(),
    val testedModel: String = "",
    val testTime: Long = 0,
    val name: String = "",
    val persona: String = "",
    val tone: String = "friendly",
    val memories: List<Memory> = emptyList(),
    val consent: Boolean = false,
    val disclose: Boolean = true,
    val delayMs: Long = 2200,
    val sentCount: Int = 0,
    val events: List<ActivityEntry> = emptyList()
)

object SadaStore {
    private val mutable = MutableStateFlow(AppData())
    val state = mutable.asStateFlow()
    val storageError = MutableStateFlow(false)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private var initialized = false
    private lateinit var file: AtomicFile
    private lateinit var key: SecretKey
    private val writes = Channel<AppData>(Channel.CONFLATED)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Synchronized fun init(context: Context) {
        if (initialized) return
        file = AtomicFile(File(context.applicationContext.filesDir, "sada.secure"))
        try {
            val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            key = (ks.getKey("sada_v1", null) as? SecretKey) ?: KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
                init(KeyGenParameterSpec.Builder("sada_v1", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
            }.generateKey()
            if (file.baseFile.exists()) {
                val pieces = file.openRead().bufferedReader().use { it.readText() }.split(":", limit = 2)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, Base64.decode(pieces[0], Base64.NO_WRAP)))
                mutable.value = json.decodeFromString<AppData>(String(cipher.doFinal(Base64.decode(pieces[1], Base64.NO_WRAP)), Charsets.UTF_8))
            }
        } catch (_: Exception) { storageError.value = true }
        initialized = true
        scope.launch {
            for (data in writes) {
                var output: java.io.FileOutputStream? = null
                try {
                    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                    cipher.init(Cipher.ENCRYPT_MODE, key)
                    val encoded = Base64.encodeToString(cipher.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(cipher.doFinal(json.encodeToString(data).toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)
                    output = file.startWrite()
                    output.write(encoded.toByteArray(Charsets.UTF_8))
                    file.finishWrite(output)
                    storageError.value = false
                } catch (_: Exception) { if (output != null) file.failWrite(output); storageError.value = true }
            }
        }
    }

    @Synchronized fun update(transform: (AppData) -> AppData) {
        val updated = transform(mutable.value)
        mutable.value = updated
        writes.trySend(updated)
    }
    fun event(ar: String, en: String, kind: String = "info") = update { it.copy(events = (listOf(ActivityEntry(ar = ar, en = en, kind = kind)) + it.events).take(80)) }
    fun clear() = update { AppData(arabic = it.arabic, dark = it.dark) }
}

fun AppData.word(ar: String, en: String) = if (arabic) ar else en
