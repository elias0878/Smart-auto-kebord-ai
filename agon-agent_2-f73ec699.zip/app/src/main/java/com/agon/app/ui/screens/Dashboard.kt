package com.agon.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.AppData
import com.agon.app.data.word
import com.agon.app.ui.components.*
import kotlin.math.*

@Composable fun Dashboard(data: AppData, active: Boolean, onNavigate: (Int) -> Unit, onSetup: () -> Unit, onTest: () -> Unit, onActivity: () -> Unit, onStop: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(start = 22.dp, end = 22.dp, top = 8.dp, bottom = 26.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).clip(RoundedCornerShape(16.dp)).background(Forest), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.GraphicEq, null, tint = Lime, modifier = Modifier.size(27.dp))
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(tr("صدى", "sada"), fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 31.sp)
                    Text(tr("امتدادٌ لشخصيتك", "Naturally, you."), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Box(Modifier.size(42.dp).clip(CircleShape).border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape).clickable(onClick = onActivity), contentAlignment = Alignment.Center) {
                    Icon(Icons.Outlined.NotificationsNone, tr("النشاط", "Activity"), modifier = Modifier.size(22.dp))
                    if (data.events.isNotEmpty()) Box(Modifier.align(Alignment.TopEnd).padding(9.dp).size(5.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
                }
            }
        }
        item {
            Column {
                Text(tr("مساحتك، بطريقتك", "YOUR PERSONAL SPACE"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(if (data.name.isBlank()) tr("أهلاً بك في صدى", "Welcome to Sada") else tr("أهلاً، ${data.name}", "Hello, ${data.name}"), fontSize = 25.sp, fontWeight = FontWeight.Bold)
            }
        }
        item {
            Box(Modifier.fillMaxWidth().height(228.dp).clip(RoundedCornerShape(27.dp)).background(Brush.linearGradient(listOf(Color(0xFF183E31), Color(0xFF0F2E24))))) {
                OrbitArt(Modifier.align(Alignment.CenterEnd).offset(x = 45.dp, y = 12.dp).size(210.dp))
                Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(6.dp).clip(CircleShape).background(Lime))
                        Spacer(Modifier.width(7.dp))
                        Text(tr("ذكاء يفهمك", "THOUGHTFULLY INTELLIGENT"), fontSize = 10.sp, color = Color(0xFFB9D7C1), letterSpacing = .5.sp)
                    }
                    Text(tr("حضورك،\nحتى وأنت مشغول.", "Your voice.\nEven when you’re away."), color = Color(0xFFF6F9ED), fontSize = 27.sp, lineHeight = 41.sp, fontWeight = FontWeight.Bold)
                    Text(tr("ردود ذكية بأسلوبك، وفي الوقت المناسب.", "Thoughtful replies. Unmistakably you."), color = Color(0xFFB0C6B8), fontSize = 10.sp)
                    Button(onClick = onSetup, colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Forest), shape = RoundedCornerShape(12.dp), contentPadding = PaddingValues(horizontal = 17.dp, vertical = 0.dp), modifier = Modifier.height(41.dp)) {
                        Text(tr("إعداد وكيلك الشخصي", "Set up your assistant"), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(14.dp))
                        Icon(Icons.AutoMirrored.Rounded.ArrowForward, null, modifier = Modifier.size(17.dp))
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(20.dp)).padding(horizontal = 17.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(39.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                    Icon(if (active) Icons.Rounded.Bolt else Icons.Rounded.PowerSettingsNew, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(tr("الوضع التلقائي", "Autopilot"), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(5.dp).clip(CircleShape).background(if (active) Color(0xFF65A968) else Color(0xFFA8AEA1)))
                        Spacer(Modifier.width(5.dp))
                        Text(if (active) tr("نشط في المحادثة المحددة", "Active in your selected chat") else tr("متوقف • أنت المتحكم دائماً", "Paused · You’re always in control"), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Switch(checked = active, onCheckedChange = { if (active) onStop() else onSetup() }, modifier = Modifier.height(28.dp), colors = SwitchDefaults.colors(uncheckedTrackColor = MaterialTheme.colorScheme.surfaceVariant, uncheckedBorderColor = Color.Transparent, uncheckedThumbColor = Color(0xFFB4BCAE)))
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(11.dp)) {
                SectionTitle(tr("مصمم ليشبهك", "MADE TO SOUND LIKE YOU"))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.height(IntrinsicSize.Min)) {
                    FeatureCard(Modifier.weight(1f), Icons.Outlined.Fingerprint, tr("شخصيتك وذاكرتك", "Persona & memory"), tr("كل ما يجعلك… أنت", "Everything that makes you, you"), tr("خصّص شخصيتك", "Make it yours"), Color(0xFFEAF0DC), Color(0xFF5B7143)) { onNavigate(1) }
                    FeatureCard(Modifier.weight(1f), Icons.Outlined.AutoAwesome, tr("اتصال أذكى", "A smarter connection"), tr("مدعوم بذكاء Gemini", "Powered by Gemini"), if (data.testedModel.isNotEmpty()) tr("متصل", "Connected") else tr("أضف مفتاح API", "Connect your API key"), Color(0xFFEDEAF5), Color(0xFF81729D)) { onNavigate(3) }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surfaceVariant).clickable(onClick = onTest).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.ChatBubbleOutline, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(25.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(tr("كيف سيردّ صدى عنك؟", "What would Sada say?"), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(tr("جرّب شخصيتك قبل تفعيل الوكيل", "Try your persona before going live"), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Icon(Icons.AutoMirrored.Rounded.ArrowForward, null, modifier = Modifier.size(20.dp))
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SectionTitle(tr("خطوات بسيطة للبدء", "YOUR QUICK START"), tr("${listOf(data.testedModel.isNotBlank(), data.persona.isNotBlank(), data.consent).count { it }} من ٣", "${listOf(data.testedModel.isNotBlank(), data.persona.isNotBlank(), data.consent).count { it }} of 3"), onSetup)
                Panel {
                    SetupLine("01", tr("اربط Gemini", "Connect Gemini"), tr("مفتاحك، نماذجك، واختيارك", "Your key. Your models. Your choice."), data.testedModel.isNotBlank()) { onNavigate(3) }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 10.dp))
                    SetupLine("02", tr("عرّفنا عليك", "Make it personal"), tr("أضف أسلوبك وذكرياتك", "Add your voice and memories"), data.persona.isNotBlank()) { onNavigate(1) }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, modifier = Modifier.padding(vertical = 10.dp))
                    SetupLine("03", tr("فعّل لوحة صدى", "Enable Sada Keyboard"), tr("ثم اختر المحادثة التي تريدها", "Then select a conversation"), data.consent) { onNavigate(2) }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.VerifiedUser, null, modifier = Modifier.size(13.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.width(6.dp))
                Text(tr("بياناتك مشفرة على جهازك. القرار لك.", "Encrypted on your device. Always your choice."), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable private fun FeatureCard(modifier: Modifier, icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, action: String, bg: Color, tint: Color, onClick: () -> Unit) {
    Column(modifier.fillMaxHeight().clip(RoundedCornerShape(22.dp)).background(MaterialTheme.colorScheme.surface).border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .7f), RoundedCornerShape(22.dp)).clickable(onClick = onClick).padding(16.dp)) {
        IconTile(icon, tint, bg, 42)
        Spacer(Modifier.height(15.dp))
        Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(2.dp))
        Text(subtitle, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, lineHeight = 17.sp)
        Spacer(Modifier.height(15.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(action, fontSize = 10.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Icon(Icons.AutoMirrored.Rounded.ArrowForward, null, modifier = Modifier.size(15.dp), tint = MaterialTheme.colorScheme.primary)
        }
    }
}
@Composable private fun SetupLine(number: String, title: String, subtitle: String, done: Boolean, click: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = click), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(34.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
            if (done) Icon(Icons.Rounded.Check, null, modifier = Modifier.size(17.dp), tint = MaterialTheme.colorScheme.primary)
            else Text(number, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.AutoMirrored.Rounded.ArrowForward, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
@Composable private fun OrbitArt(modifier: Modifier) {
    Canvas(modifier) {
        val c = Offset(size.width * .55f, size.height * .48f)
        for (i in 0..4) {
            drawCircle(Color(0xFFADCDAA).copy(alpha = .08f + i * .012f), size.width * (.21f + i * .082f), center = c, style = Stroke(1.dp.toPx()))
        }
        drawCircle(Brush.radialGradient(listOf(Color(0xFF8CA97A).copy(alpha = .28f), Color.Transparent), center = c, radius = size.width * .42f), size.width * .42f, c)
        for (i in 0..8) {
            val h = (18 + 34 * sin(i / 8f * PI).toFloat()) * density
            val x = c.x + (i - 4) * 8.dp.toPx()
            drawLine(Color(0xFFCEF59C).copy(alpha = .25f + .15f * sin(i.toFloat())), Offset(x, c.y - h / 2), Offset(x, c.y + h / 2), strokeWidth = 3.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
        }
        drawCircle(Lime.copy(alpha = .75f), 3.dp.toPx(), Offset(c.x - size.width * .33f, c.y - size.height * .19f))
        drawCircle(Lime.copy(alpha = .45f), 2.dp.toPx(), Offset(c.x + size.width * .12f, c.y + size.height * .35f))
    }
}
