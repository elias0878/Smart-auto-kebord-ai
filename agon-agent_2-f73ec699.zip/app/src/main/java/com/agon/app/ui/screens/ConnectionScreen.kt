package com.agon.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.*
import com.agon.app.service.SadaAgentService
import com.agon.app.ui.components.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun ConnectionScreen(data: AppData, notify: (String) -> Unit) {
    var key by remember { mutableStateOf(data.key) }
    var visible by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf("") }
    var success by rememberSaveable { mutableStateOf("") }
    var modelsOpen by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    fun test(refresh: Boolean) {
        scope.launch {
            loading = true; error = ""; success = ""
            SadaAgentService.stopSession()
            val requestedKey = key.trim()
            try {
                var selected = data.model
                if (refresh || requestedKey != data.key || data.models.isEmpty()) {
                    progress = data.word("أتحقق من المفتاح وأجلب النماذج…", "Checking the key and fetching models…")
                    if (requestedKey != data.key) SadaStore.update { it.copy(key = requestedKey, models = emptyList(), model = "", testedModel = "", testTime = 0) }
                    val list = GeminiClient.models(requestedKey)
                    if (list.isEmpty()) throw IllegalStateException(data.word("لا توجد نماذج تدعم generateContent لهذا المفتاح", "No generateContent models are available for this key"))
                    selected = list.firstOrNull { it.name == selected }?.name ?: list.first().name
                    SadaStore.update { it.copy(key = requestedKey, models = list, model = selected, testedModel = "", testTime = 0) }
                } else SadaStore.update { it.copy(testedModel = "", testTime = 0) }
                progress = data.word("أختبر توليد النص على النموذج المختار…", "Testing text generation with your selected model…")
                val started = System.currentTimeMillis()
                GeminiClient.generate(requestedKey, selected, "This is an API connectivity test. Reply only with OK.", "Reply OK.")
                val elapsed = System.currentTimeMillis() - started
                SadaStore.update { it.copy(testedModel = selected, testTime = System.currentTimeMillis()) }
                success = data.word("نجح التوليد الفعلي • ${elapsed}ms", "Live generation passed · ${elapsed}ms")
                SadaStore.event("نجح اختبار اتصال Gemini وتوليد النص", "Gemini connection and text generation verified", "success")
                notify(data.word("اتصالك جاهز", "Your connection is ready"))
            } catch (cancelled: CancellationException) { throw cancelled }
            catch (e: Exception) {
                error = GeminiClient.errorMessage(e, data.arabic)
                SadaStore.event("فشل فحص Gemini؛ راجع شاشة الاتصال", "Gemini inspection failed; check Connection", "error")
            } finally { loading = false }
        }
    }
    LazyColumn(contentPadding = PaddingValues(22.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item { PageTitle(tr("المحرك الذكي", "THE INTELLIGENCE INSIDE"), tr("اتصال يفهمك", "Connected to intelligence"), tr("مفتاحك الخاص، ونماذج متاحة فعلياً لحسابك. بلا تخمين أو نماذج ثابتة.", "Your own key. Models available to your account. No guessed or hardcoded models.")) }
        item {
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconTile(Icons.Outlined.AutoAwesome, androidx.compose.ui.graphics.Color(0xFF81729D), androidx.compose.ui.graphics.Color(0xFFEDEAF5))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text("Google Gemini", fontSize = 17.sp, fontWeight = FontWeight.Bold); Text(tr("اتصال مباشر وآمن عبر HTTPS", "Direct, secure HTTPS connection"), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    SmallTag(if (data.testedModel == data.model && data.model.isNotEmpty()) tr("متصل", "Connected") else tr("غير متصل", "Not connected"))
                }
                Spacer(Modifier.height(22.dp))
                Text(tr("مفتاح API", "API key"), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    OutlinedTextField(key, { key = it.replace("\n", "").take(300); error = ""; success = "" }, modifier = Modifier.fillMaxWidth(), enabled = !loading, singleLine = true, placeholder = { Text("AIza…", fontSize = 13.sp) }, visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), shape = RoundedCornerShape(14.dp), trailingIcon = { IconButton(onClick = { visible = !visible }) { Icon(if (visible) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility, tr("إظهار أو إخفاء المفتاح", "Show or hide key")) } })
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Outlined.Lock, null, Modifier.size(13.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.width(6.dp)); Text(tr("يُحفظ مشفراً على هذا الجهاز فقط", "Encrypted and stored only on this device"), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                Spacer(Modifier.height(20.dp))
                PrimaryButton(if (loading) tr("جارٍ الفحص…", "Inspecting…") else tr("حفظ وفحص المفتاح", "Save & inspect key"), { test(true) }, enabled = key.trim().isNotBlank(), loading = loading)
                if (loading) { Spacer(Modifier.height(12.dp)); Text(progress, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                if (data.key.isNotBlank()) TextButton(onClick = { SadaAgentService.stopSession(); key = ""; SadaStore.update { it.copy(key = "", model = "", models = emptyList(), testedModel = "", testTime = 0) }; error = ""; success = "" }, enabled = !loading, modifier = Modifier.fillMaxWidth()) { Text(tr("إزالة المفتاح المحفوظ", "Remove saved key"), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp) }
            }
        }
        if (error.isNotEmpty()) item { Notice(error, true) }
        if (success.isNotEmpty()) item { Notice(success) }
        item {
            Panel {
                SectionTitle(tr("النموذج المستخدم", "Active model"), tr("تبديل", "Change"), { modelsOpen = true })
                Spacer(Modifier.height(10.dp))
                val selected = data.models.find { it.name == data.model }
                if (selected == null) {
                    Text(tr("ستظهر نماذجك هنا بعد فحص المفتاح.", "Your models will appear after inspecting your key."), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    Text(selected.displayName, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text(selected.name.removePrefix("models/"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(16.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        LimitBox(tr("سياق الإدخال", "Input context"), selected.inputLimit, Modifier.weight(1f))
                        LimitBox(tr("حد الإخراج", "Output limit"), selected.outputLimit, Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(12.dp))
                    if (selected.description.isNotBlank()) Text(selected.description, fontSize = 11.sp, maxLines = 4, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    TextButton(onClick = { test(false) }, enabled = !loading && key.trim() == data.key) { Icon(Icons.Outlined.PlayCircleOutline, null, Modifier.size(19.dp)); Spacer(Modifier.width(7.dp)); Text(tr("اختبار هذا النموذج فعلياً", "Run a live model test"), fontSize = 12.sp) }
                    if (data.testTime > 0 && data.testedModel == data.model) Text(tr("آخر نجاح: ", "Last passed: ") + DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(data.testTime)), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item { Notice(tr("معلومة مهمة: حدود السياق تأتي من API. أما الحصة المتبقية، الفوترة وحدود الطلبات الفعلية فلا يكشفها فحص المفتاح؛ راجع Google AI Studio. الفحص يستهلك طلب توليد صغيراً وقد يخضع للتكلفة.", "Context limits come from the API. Remaining quota, billing and effective rate limits are not exposed by key inspection; check Google AI Studio. Testing uses a small generation request and may incur cost.")) }
        item { Notice(tr("الرسائل الظاهرة وشخصيتك والذكريات ذات الصلة تُرسل مباشرة إلى Google عند التوليد. لا يمر مفتاحك عبر خادم لصدى.", "Visible messages, your persona and relevant memories are sent directly to Google during generation. Your key never passes through a Sada server.")) }
    }
    if (modelsOpen) ModalBottomSheet(onDismissRequest = { modelsOpen = false }, containerColor = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp)) {
            Text(tr("اختر نموذجك", "Choose your model"), fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(tr("${data.models.size} نموذجاً يدعم generateContent", "${data.models.size} models support generateContent"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(search, { search = it }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), placeholder = { Text(tr("ابحث عن نموذج", "Search models")) }, leadingIcon = { Icon(Icons.Outlined.Search, null) })
            LazyColumn(Modifier.heightIn(max = 420.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
                val list = data.models.filter { it.name.contains(search, true) || it.displayName.contains(search, true) }
                if (list.isEmpty()) item { Notice(tr("لا توجد نتائج. افحص المفتاح أو غيّر البحث.", "No results. Inspect your key or change your search.")) }
                items(list, key = { it.name }) { model ->
                    Row(Modifier.fillMaxWidth().clickable(enabled = !loading) { SadaAgentService.stopSession(); SadaStore.update { it.copy(model = model.name, testedModel = "", testTime = 0) }; success = ""; error = ""; modelsOpen = false }, verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = model.name == data.model, onClick = null)
                        Column(Modifier.padding(12.dp).weight(1f)) { Text(model.displayName, fontWeight = FontWeight.SemiBold, fontSize = 13.sp); Text(model.name.removePrefix("models/"), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                }
            }
        }
    }
}
@Composable private fun LimitBox(label: String, count: Int, modifier: Modifier) {
    Surface(modifier, shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.padding(12.dp)) { Text(if (count == 0) "—" else java.text.NumberFormat.getIntegerInstance().format(count), fontWeight = FontWeight.Bold, fontSize = 19.sp); Text(label + tr(" • توكن", " · tokens"), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}
