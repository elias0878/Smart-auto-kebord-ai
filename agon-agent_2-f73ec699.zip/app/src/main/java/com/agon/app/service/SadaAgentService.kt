package com.agon.app.service

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.agon.app.data.GeminiClient
import com.agon.app.data.SadaStore
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.security.MessageDigest

private fun hash(value: String): String = MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString("") { "%02x".format(it) }
data class Bubble(val text: String, val nodeId: String, val side: Int, val top: Int) {
    val pattern: String get() = "$nodeId|$side"
}
data class ChatSnapshot(val app: String, val title: String, val bubbles: List<Bubble>, val typing: Boolean, val draft: String) {
    val identity: String get() = "$app|$title"
    val signature: String get() = hash(bubbles.joinToString("\n") { "${it.pattern}:${it.text}" })
}
data class AgentStatus(val connected: Boolean = false, val active: Boolean = false, val phase: String = "idle", val ar: String = "الوضع التلقائي متوقف", val en: String = "Autopilot is paused", val chat: String = "")

class SadaAgentService : AccessibilityService() {
    companion object {
        var instance: SadaAgentService? = null
            private set
        private val mutable = MutableStateFlow(AgentStatus())
        val status = mutable.asStateFlow()
        fun stopSession() { instance?.stop("أوقفت الجلسة", "Session stopped") }
    }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var pending: Job? = null
    private var busy = false
    private var sessionId = 0L
    private var chatIdentity = ""
    private var incomingPattern = ""
    private var outgoingPattern = ""
    private var incomingSample: Bubble? = null
    private var outgoingSample: Bubble? = null
    private var calibrationIdentity = ""
    private val seen = LinkedHashSet<String>()
    private val seenTexts = LinkedHashSet<String>()
    private val sent = LinkedHashSet<String>()
    private var lastSnapshot: ChatSnapshot? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        SadaStore.init(applicationContext)
        instance = this
        mutable.value = AgentStatus(connected = true)
    }
    override fun onInterrupt() { stop("أوقف النظام خدمة الوصول", "Accessibility was interrupted") }
    override fun onDestroy() {
        stop("انقطع اتصال خدمة الوصول", "Accessibility disconnected")
        scope.cancel()
        instance = null
        mutable.value = AgentStatus()
        super.onDestroy()
    }
    fun stop(ar: String, en: String) {
        val wasActive = mutable.value.active
        sessionId++
        pending?.cancel()
        pending = null
        busy = false
        mutable.value = AgentStatus(connected = true, ar = ar, en = en)
        if (wasActive) SadaStore.event(ar, en)
    }
    private fun phase(id: String, ar: String, en: String) { mutable.value = mutable.value.copy(phase = id, ar = ar, en = en) }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!mutable.value.active || event == null || busy) return
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED || event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || event.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED || event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) schedule()
    }
    private fun nodes(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val list = ArrayList<AccessibilityNodeInfo>()
        fun visit(n: AccessibilityNodeInfo, depth: Int) {
            if (depth > 35 || list.size >= 1600) return
            list += n
            for (i in 0 until n.childCount) n.getChild(i)?.let { visit(it, depth + 1) }
        }
        visit(root, 0)
        return list
    }
    private fun rect(node: AccessibilityNodeInfo) = Rect().also { node.getBoundsInScreen(it) }
    private fun isEditor(node: AccessibilityNodeInfo) = node.isEditable && node.isVisibleToUser && !node.isPassword
    private fun isTime(text: String) = text.matches(Regex("[\\d٠-٩\\s:./APMapm،✓✔]+")) || text.length < 2
    private fun applicationRoot(): AccessibilityNodeInfo? {
        val focused = windows.firstOrNull { it.type == android.view.accessibility.AccessibilityWindowInfo.TYPE_APPLICATION && it.isFocused }?.root
        return focused ?: rootInActiveWindow
    }

    fun capture(): ChatSnapshot? = try { captureTree() } catch (_: Exception) { null }

    private fun captureTree(): ChatSnapshot? {
        val root = applicationRoot() ?: return null
        val app = root.packageName?.toString() ?: return null
        if (app == packageName || app.startsWith("com.android.") || app.startsWith("com.google.android.inputmethod")) return null
        val all = nodes(root).filter { it.isVisibleToUser }
        val editor = all.firstOrNull(::isEditor) ?: return null
        val inputTop = rect(editor).top
        val screen = rect(root)
        if (screen.width() <= 0) return null
        val titleNodes = all.filter { n ->
            val id = n.viewIdResourceName.orEmpty().lowercase()
            !n.text.isNullOrBlank() && !n.isEditable && rect(n).bottom < inputTop && rect(n).top < screen.top + screen.height() * .30 &&
                (id.endsWith("/conversation_contact_name") || id.endsWith("/title") || id.endsWith("/action_bar_title") || id.endsWith("/chat_title") || id.endsWith("/toolbar_title") || id.endsWith("/header_title"))
        }
        val titleNode = titleNodes.minByOrNull { rect(it).top } ?: return null
        val title = titleNode.text.toString().trim()
        if (title.isEmpty()) return null
        val titleBottom = rect(titleNode).bottom
        val scrollContainers = all.filter { n ->
            val cls = n.className?.toString().orEmpty()
            (cls.contains("RecyclerView") || cls.contains("ListView") || cls.contains("ScrollView")) && rect(n).top >= titleBottom && rect(n).bottom > titleBottom + 100
        }
        val scroll = scrollContainers.maxByOrNull { rect(it).height() } ?: return null
        val bubbleList = mutableListOf<Bubble>()
        for (i in 0 until scroll.childCount) {
            val row = scroll.getChild(i) ?: continue
            val leaves = nodes(row).filter { n ->
                val value = n.text?.toString()?.trim().orEmpty()
                n.isVisibleToUser && !n.isEditable && !n.isPassword && value.isNotEmpty() && value.length < 8000 && !isTime(value) &&
                    !n.viewIdResourceName.isNullOrBlank() && rect(n).top > titleBottom && rect(n).bottom <= inputTop && !n.className.toString().contains("Button") &&
                    !n.viewIdResourceName.orEmpty().contains("date", true) && !n.viewIdResourceName.orEmpty().contains("sender", true) && !n.viewIdResourceName.orEmpty().contains("name", true)
            }
            val leaf = leaves.maxByOrNull { n ->
                val id = n.viewIdResourceName.orEmpty()
                (n.text?.length ?: 0) + if (id.contains("message", true) || id.contains("text", true)) 1000 else 0
            } ?: continue
            var bound = rect(leaf)
            var parent = leaf.parent
            var tries = 0
            while (parent != null && tries < 8) {
                val r = rect(parent)
                if (r.width() >= screen.width() * .92f || r.top < rect(row).top || r.bottom > rect(row).bottom) break
                if (r.width() > bound.width()) bound = r
                parent = parent.parent
                tries++
            }
            val left = bound.left - screen.left
            val right = screen.right - bound.right
            val difference = left - right
            val side = when {
                difference > screen.width() * .06f -> 1
                difference < -screen.width() * .06f -> -1
                else -> 0
            }
            bubbleList += Bubble(leaf.text.toString().trim(), leaf.viewIdResourceName.orEmpty(), side, rect(leaf).top)
        }
        val typing = all.any { n -> rect(n).top < screen.top + screen.height() * .3f && (n.text?.toString().orEmpty() + " " + n.contentDescription?.toString().orEmpty()).let { it.contains("typing", true) || it.contains("يكتب") || it.contains("جارٍ الكتابة") } }
        return ChatSnapshot(app, title, bubbleList.distinctBy { "${it.top}|${it.text}" }.sortedBy { it.top }.takeLast(30), typing, editor.text?.toString().orEmpty().let { if (android.os.Build.VERSION.SDK_INT >= 26 && it == editor.hintText?.toString()) "" else it })
    }

    fun calibrate(snapshot: ChatSnapshot, bubble: Bubble, incoming: Boolean): String? {
        if (mutable.value.active) stop("توقفت الجلسة لإعادة المعايرة", "Paused for recalibration")
        val current = capture() ?: return "screen"
        if (snapshot.identity != current.identity || current.bubbles.none { it.text == bubble.text && it.pattern == bubble.pattern }) return "changed"
        if (calibrationIdentity != current.identity) {
            incomingSample = null; outgoingSample = null
            calibrationIdentity = current.identity
        }
        if (bubble.side == 0 || bubble.nodeId.isBlank()) return "ambiguous"
        if (incoming) incomingSample = bubble else outgoingSample = bubble
        return null
    }
    fun calibrationLabel(arabic: Boolean): String {
        val incoming = incomingSample?.text?.take(25) ?: "—"
        val outgoing = outgoingSample?.text?.take(25) ?: "—"
        return if (arabic) "واردة: $incoming\nمني: $outgoing" else "Incoming: $incoming\nMine: $outgoing"
    }
    fun startSession(): String? {
        val data = SadaStore.state.value
        if (!data.consent) return if (data.arabic) "وافق على استخدام خدمة الوصول من إعدادات لوحة المفاتيح أولاً" else "Accept accessibility disclosure in Keyboard settings first"
        if (data.key.isBlank() || data.model.isBlank() || data.testedModel != data.model) return if (data.arabic) "اختبر النموذج المحدد أولاً من شاشة الاتصال" else "Test your selected model in Connection first"
        val snap = capture() ?: return if (data.arabic) "تعذّر تحديد عنوان المحادثة ورسائلها. هذه الشاشة غير مدعومة." else "Cannot identify chat title and messages. This screen is unsupported."
        val inc = incomingSample
        val own = outgoingSample
        if (inc == null || own == null || calibrationIdentity != snap.identity || inc.pattern == own.pattern || inc.side == own.side) return if (data.arabic) "عاير المحادثة: اختر رسالة واردة ورسالة منك على جهتين مختلفتين" else "Calibrate: select one incoming message and one of yours on opposite sides"
        if (snap.draft.isNotBlank()) return if (data.arabic) "أفرغ مسودة الكتابة أولاً" else "Clear the existing draft first"
        chatIdentity = snap.identity
        incomingPattern = inc.pattern
        outgoingPattern = own.pattern
        seen.clear(); seenTexts.clear(); sent.clear()
        snap.bubbles.forEachIndexed { index, bubble -> if (bubble.pattern == incomingPattern) { seen += fingerprint(snap, index); seenTexts += hash(bubble.text) } }
        lastSnapshot = snap
        sessionId++
        mutable.value = AgentStatus(true, true, "watching", "بانتظار رسالة جديدة", "Waiting for a new message", snap.title)
        SadaStore.event("بدأت جلسة تلقائية في محادثة مختارة", "Started an automatic session in a selected conversation", "success")
        schedule()
        return null
    }
    private fun fingerprint(snap: ChatSnapshot, index: Int): String = hash(snap.identity + snap.bubbles.subList((index - 2).coerceAtLeast(0), index + 1).joinToString("\n") { "${it.pattern}:${it.text}" })
    private fun schedule() {
        if (!mutable.value.active || busy) return
        pending?.cancel()
        pending = scope.launch { delay(SadaStore.state.value.delayMs); process() }
    }
    private suspend fun process() {
        if (!mutable.value.active || busy) return
        val snap = capture()
        if (snap == null || snap.identity != chatIdentity) { stop("توقفت الجلسة: تغيّرت المحادثة أو تعذّرت قراءتها", "Stopped: conversation changed or cannot be read"); return }
        if (snap.typing) { phase("waiting", "الطرف الآخر يكتب…", "The other person is typing…"); schedule(); return }
        if (snap.draft.isNotBlank()) { stop("توقفت الجلسة لحماية مسودتك", "Stopped to protect your draft"); return }
        val previous = lastSnapshot
        lastSnapshot = snap
        val last = snap.bubbles.lastOrNull() ?: return
        if (previous != null && previous.bubbles.isNotEmpty() && snap.bubbles.none { current -> previous.bubbles.any { old -> old.text == current.text && old.pattern == current.pattern } }) {
            stop("تغيّرت الرسائل الظاهرة بالكامل؛ أعد تفعيل الجلسة", "Visible message history changed completely; start a new session"); return
        }
        if (last.pattern == outgoingPattern || hash(last.text) in sent || hash(last.text) in seenTexts) return
        if (last.pattern != incomingPattern) { phase("uncertain", "لن أرسل: اتجاه الرسالة غير واضح", "Not sending: message direction is unclear"); return }
        val fingerprint = fingerprint(snap, snap.bubbles.lastIndex)
        if (fingerprint in seen) return
        busy = true
        val token = sessionId
        val data = SadaStore.state.value
        try {
            phase("thinking", "أفهم السياق وأكتب بأسلوبك…", "Understanding context and writing in your voice…")
            val context = snap.bubbles.joinToString("\n") { "${if (it.pattern == incomingPattern) "OTHER" else if (it.pattern == outgoingPattern) "OWNER" else "UNKNOWN"}: ${it.text}" }
            val systemPrompt = withContext(Dispatchers.Default) { GeminiClient.system(data, context) }
            val generated = GeminiClient.generate(data.key, data.model, systemPrompt, "Conversation with ${snap.title}. Reply to the latest OTHER message:\n$context")
            val prefix = if (data.arabic) "[مساعد صدى] " else "[Sada assistant] "
            val reply = if (data.disclose && !generated.startsWith(prefix.trim())) prefix + generated else generated
            if (reply.length > 3000) { stop("الرد أطول من الحد الآمن؛ لم يُرسل", "Reply exceeds the safe length; not sent"); return }
            currentCoroutineContext().ensureActive()
            if (!mutable.value.active || token != sessionId) return
            val fresh = capture()
            if (fresh == null || fresh.identity != chatIdentity) { stop("تغيّرت المحادثة؛ لم يُرسل الرد", "Chat changed; reply was not sent"); return }
            if (fresh.signature != snap.signature || fresh.typing) { phase("waiting", "وصل تحديث؛ أعيد قراءة السياق", "New activity; reading context again"); return }
            if (fresh.draft.isNotBlank()) { stop("لم يُرسل الرد لحماية مسودتك", "Reply not sent to protect your draft"); return }
            val editor = applicationRoot()?.let(::nodes)?.firstOrNull(::isEditor) ?: run { stop("لم أجد حقل الكتابة", "Message field unavailable"); return }
            phase("sending", "أرسل الرد…", "Sending reply…")
            val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, reply) }
            if (!editor.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) { stop("تعذّرت الكتابة في هذا التطبيق", "This app does not allow text insertion"); return }
            delay(350)
            if (token != sessionId || !mutable.value.active) return
            val beforeSend = capture()
            if (beforeSend == null || beforeSend.identity != chatIdentity || beforeSend.signature != snap.signature || beforeSend.typing || beforeSend.draft.trim() != reply.trim()) {
                clearGeneratedDraft(reply)
                stop("تغيّر السياق؛ أوقفت الإرسال", "Context changed; sending stopped"); return
            }
            val sends = applicationRoot()?.let(::nodes)?.filter { n ->
                val id = n.viewIdResourceName.orEmpty().substringAfterLast('/').lowercase()
                val label = (n.contentDescription ?: n.text)?.toString()?.trim()?.lowercase().orEmpty()
                n.isVisibleToUser && n.isEnabled && n.isClickable && (id in setOf("send", "send_button", "btn_send", "send_message_button") || label in setOf("send", "send message", "إرسال", "ارسال", "إرسال رسالة"))
            }.orEmpty()
            if (sends.size != 1) { clearGeneratedDraft(reply); stop("زر الإرسال غير محدد بأمان", "Cannot safely identify a single Send button"); return }
            seen += fingerprint
            seenTexts += hash(last.text)
            sent += hash(reply)
            if (!sends.single().performAction(AccessibilityNodeInfo.ACTION_CLICK)) { clearGeneratedDraft(reply); stop("لم يتمكن النظام من الضغط على إرسال", "Could not press Send"); return }
            delay(900)
            val confirmation = capture()
            if (confirmation != null && confirmation.identity == chatIdentity && confirmation.draft.isBlank() && confirmation.bubbles.any { it.pattern == outgoingPattern && it.text.trim() == reply.trim() }) {
                SadaStore.update { it.copy(sentCount = it.sentCount + 1) }
                SadaStore.event("تم تأكيد إرسال رد تلقائي", "Automatic reply confirmed on screen", "success")
                phase("watching", "تم الرد • بانتظار رسالة جديدة", "Replied · Waiting for a new message")
            } else stop("لم أستطع تأكيد الإرسال؛ توقفت لمنع التكرار", "Could not confirm delivery; stopped to prevent duplicates")
        } catch (cancelled: CancellationException) { throw cancelled }
        catch (error: Exception) {
            stop("تعذّر توليد الرد؛ راجع الاتصال", "Generation failed; check Connection")
            val code = (error as? com.agon.app.data.ApiFailure)?.status
            SadaStore.event("تعذّر الاتصال أو التوليد${code?.let { ": HTTP $it" }.orEmpty()}؛ راجع فحص المفتاح", "Connection or generation failed${code?.let { ": HTTP $it" }.orEmpty()}; inspect your key", "error")
        } finally {
            if (token == sessionId) {
                busy = false
                if (mutable.value.active) schedule()
            }
        }
    }
    private fun clearGeneratedDraft(reply: String) {
        val current = capture() ?: return
        if (current.identity != chatIdentity || current.draft.trim() != reply.trim()) return
        val editor = applicationRoot()?.let(::nodes)?.firstOrNull(::isEditor) ?: return
        editor.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "") })
    }
}
