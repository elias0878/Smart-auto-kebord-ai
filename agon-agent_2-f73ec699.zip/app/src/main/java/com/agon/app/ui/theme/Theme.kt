package com.agon.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = androidx.compose.ui.graphics.Color(0xFFBCF084),
    onPrimary = androidx.compose.ui.graphics.Color(0xFF183C32),
    secondary = androidx.compose.ui.graphics.Color(0xFFB9CEC4),
    background = androidx.compose.ui.graphics.Color(0xFF101B17),
    surface = androidx.compose.ui.graphics.Color(0xFF19251F),
    surfaceVariant = androidx.compose.ui.graphics.Color(0xFF26362E),
    onBackground = androidx.compose.ui.graphics.Color(0xFFF0F4EE),
    onSurface = androidx.compose.ui.graphics.Color(0xFFF0F4EE),
    onSurfaceVariant = androidx.compose.ui.graphics.Color(0xFFA8B9AF),
    outlineVariant = androidx.compose.ui.graphics.Color(0xFF35463C),
)

private val LightColorScheme = lightColorScheme(
    primary = androidx.compose.ui.graphics.Color(0xFF214F3E),
    onPrimary = androidx.compose.ui.graphics.Color.White,
    secondary = androidx.compose.ui.graphics.Color(0xFF65806E),
    background = androidx.compose.ui.graphics.Color(0xFFF6F7F2),
    surface = androidx.compose.ui.graphics.Color.White,
    surfaceVariant = androidx.compose.ui.graphics.Color(0xFFEDF1E8),
    onBackground = androidx.compose.ui.graphics.Color(0xFF172C22),
    onSurface = androidx.compose.ui.graphics.Color(0xFF172C22),
    onSurfaceVariant = androidx.compose.ui.graphics.Color(0xFF7A847B),
    outlineVariant = androidx.compose.ui.graphics.Color(0xFFE5E9DF),
)

@Composable
fun AgonAppTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    val font = androidx.compose.ui.text.font.FontFamily(androidx.compose.ui.text.font.Font(com.agon.app.R.font.cairo))
    val defaults = androidx.compose.material3.Typography()
    val typography = androidx.compose.material3.Typography(
        displayLarge = defaults.displayLarge.copy(fontFamily = font),
        displayMedium = defaults.displayMedium.copy(fontFamily = font),
        displaySmall = defaults.displaySmall.copy(fontFamily = font),
        headlineLarge = defaults.headlineLarge.copy(fontFamily = font),
        headlineMedium = defaults.headlineMedium.copy(fontFamily = font),
        headlineSmall = defaults.headlineSmall.copy(fontFamily = font),
        titleLarge = defaults.titleLarge.copy(fontFamily = font),
        titleMedium = defaults.titleMedium.copy(fontFamily = font),
        titleSmall = defaults.titleSmall.copy(fontFamily = font),
        bodyLarge = defaults.bodyLarge.copy(fontFamily = font),
        bodyMedium = defaults.bodyMedium.copy(fontFamily = font),
        bodySmall = defaults.bodySmall.copy(fontFamily = font),
        labelLarge = defaults.labelLarge.copy(fontFamily = font),
        labelMedium = defaults.labelMedium.copy(fontFamily = font),
        labelSmall = defaults.labelSmall.copy(fontFamily = font)
    )
    MaterialTheme(colorScheme = colorScheme, typography = typography, content = content)
}
