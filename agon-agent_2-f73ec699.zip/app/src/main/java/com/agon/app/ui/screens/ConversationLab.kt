package com.agon.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.*
import com.agon.app.ui.components.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun ConversationLab(data: AppData, dismiss: () -> Unit, connect: () -> Unit) {
    val messages = remember { mutableStateListOf<Pair<Boolean, String>>() }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val list = rememberLazyListState()
    LaunchedEffect(messages.size, busy) { if (messages.isNotEmpty()) list.animateScrollToItem(messages.size - 1) }
    ModalBottomSheet(onDismissRequest = dismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxWidth().fillMaxHeight(.88f).padding(horizontal = 22.dp).imePadding()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconTile(Icons.Outlined.ChatBubbleOutline)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) { Text(tr("مختبر شخصيتك", "Your persona lab"), fontSize = 22.sp, fontWeight = FontWeight.Bold); Text(tr("تجربة خاصة • لا ترسل لأي شخص", "Private preview · Never sent to a contact"), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                IconButton(onClick = { messages.clear(); error = "" }, enabled = !busy) { Icon(Icons.Outlined.DeleteSweep, tr("مسح التجربة", "Clear preview")) }
            }
            Spacer(Modifier.height(16.dp))
            if (data.testedModel != data.model || data.model.isBlank()) {
                Notice(tr("اربط Gemini واختبر النموذج أولاً لتجربة رد حقيقي بأسلوبك.", "Connect Gemini and test a model to try a real reply in your voice."))
                Spacer(Modifier.height(12.dp))
                PrimaryButton(tr("إعداد الاتصال", "Set up connection"), connect)
            }
            if (messages.isEmpty()) Column(Modifier.weight(1f).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(Icons.Outlined.Forum, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = .4f))
                Spacer(Modifier.height(18.dp))
                Text(tr("تخيّل أن صديقاً يراسلك…", "Imagine a friend messages you…"), fontWeight = FontWeight.Bold)
                Text(tr("اكتب رسالته وشاهد رد صدى بصوتك.", "Write their message. See Sada reply in your voice."), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                SuggestionChip(onClick = { input = data.word("كيف كان يومك؟", "How was your day?") }, label = { Text(tr("كيف كان يومك؟", "How was your day?"), fontSize = 12.sp) })
            } else LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
                items(messages.toList()) { (assistant, text) ->
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (assistant) Alignment.Start else Alignment.End) {
                        Text(if (assistant) tr("صدى بأسلوبك", "Sada, in your voice") else tr("الطرف الآخر", "The other person"), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(text, modifier = Modifier.widthIn(max = 310.dp).clip(RoundedCornerShape(18.dp)).background(if (assistant) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface).padding(14.dp), fontSize = 13.sp, lineHeight = 24.sp)
                    }
                }
            }
            if (busy) Row(Modifier.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(15.dp), strokeWidth = 2.dp); Spacer(Modifier.width(10.dp)); Text(tr("يفهمك، ثم يرد…", "Finding your words…"), fontSize = 11.sp) }
            if (error.isNotEmpty()) { Notice(error, true); TextButton(onClick = { input = messages.lastOrNull { !it.first }?.second.orEmpty(); error = "" }) { Text(tr("حاول مجدداً", "Try again")) } }
            Row(Modifier.padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(input, { input = it.take(4000) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(18.dp), maxLines = 3, placeholder = { Text(tr("رسالة الطرف الآخر…", "Their message…"), fontSize = 12.sp) }, enabled = !busy)
                FilledIconButton(onClick = {
                    val message = input.trim(); input = ""; error = ""; messages += false to message
                    scope.launch {
                        busy = true
                        try {
                            val transcript = messages.joinToString("\n") { if (it.first) "OWNER: ${it.second}" else "OTHER: ${it.second}" }.takeLast(20000)
                            val systemPrompt = withContext(Dispatchers.Default) { GeminiClient.system(data, transcript) }
                            val response = GeminiClient.generate(data.key, data.model, systemPrompt, "Reply to the latest OTHER message in this practice conversation:\n$transcript")
                            messages += true to response
                        } catch (cancelled: CancellationException) { throw cancelled }
                        catch (e: Exception) { error = GeminiClient.errorMessage(e, data.arabic) }
                        finally { busy = false }
                    }
                }, enabled = !busy && input.isNotBlank() && data.model.isNotBlank() && data.testedModel == data.model, modifier = Modifier.size(49.dp)) { Icon(Icons.AutoMirrored.Outlined.Send, tr("تجربة الرد", "Generate a reply")) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun ActivitySheet(data: AppData, dismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = dismiss, containerColor = MaterialTheme.colorScheme.background) {
        LazyColumn(Modifier.fillMaxWidth().heightIn(min = 280.dp, max = 650.dp), contentPadding = PaddingValues(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item { SectionTitle(tr("نبض صدى", "Sada activity"), tr("مسح السجل", "Clear log"), { SadaStore.update { it.copy(events = emptyList()) } }) }
            item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text(tr("الردود المؤكدة منذ الإعداد", "Confirmed replies since setup"), fontSize = 13.sp); SmallTag("${data.sentCount}") } }
            if (data.events.isEmpty()) item {
                Panel { IconTile(Icons.Outlined.History); Spacer(Modifier.height(15.dp)); Text(tr("لم تبدأ الحكاية بعد", "Your story starts here"), fontWeight = FontWeight.Bold); Text(tr("ستظهر هنا اختبارات الاتصال وأحداث الجلسة، دون الاحتفاظ بنصوص المحادثات.", "Connection tests and session events will appear here, without storing your conversations."), fontSize = 12.sp, lineHeight = 23.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            items(data.events) { event ->
                Panel {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (event.kind == "error") Icons.Outlined.ErrorOutline else if (event.kind == "success") Icons.Outlined.CheckCircle else Icons.Outlined.Info, null, tint = if (event.kind == "error") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(if (data.arabic) event.ar else event.en, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(event.at)), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            item { Notice(tr("السجل يحتفظ بآخر 80 حدثاً على هذا الجهاز فقط.", "Only the latest 80 events are retained on this device.")) }
        }
    }
}
