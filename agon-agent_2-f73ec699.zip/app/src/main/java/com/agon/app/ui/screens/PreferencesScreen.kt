package com.agon.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.*
import com.agon.app.service.SadaAgentService
import com.agon.app.ui.components.*

@Composable fun PreferencesScreen(data: AppData, onActivity: () -> Unit, notify: (String) -> Unit) {
    var erase by remember { mutableStateOf(false) }
    var about by remember { mutableStateOf(false) }
    var delay by remember(data.delayMs) { mutableFloatStateOf(data.delayMs.toFloat()) }
    LazyColumn(contentPadding = PaddingValues(22.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item { PageTitle(tr("على راحتك", "MAKE YOURSELF AT HOME"), tr("كل شيء، بطريقتك", "Everything, your way"), tr("اللغة، المظهر، والحدود التي يرتاح لها بالك.", "Your language, your look, and boundaries you feel good about.")) }
        item {
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) { IconTile(Icons.Outlined.Language); Spacer(Modifier.width(12.dp)); Text(tr("لغة التطبيق", "App language"), fontWeight = FontWeight.Bold) }
                Spacer(Modifier.height(16.dp))
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    SegmentedButton(selected = data.arabic, onClick = { SadaStore.update { it.copy(arabic = true) } }, shape = SegmentedButtonDefaults.itemShape(0, 2)) { Text("العربية") }
                    SegmentedButton(selected = !data.arabic, onClick = { SadaStore.update { it.copy(arabic = false) } }, shape = SegmentedButtonDefaults.itemShape(1, 2)) { Text("English") }
                }
                Spacer(Modifier.height(8.dp))
                Text(tr("تتغير الواجهة ولوحة المفاتيح فوراً", "App and keyboard update instantly"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(12.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                InfoRow(Icons.Outlined.DarkMode, tr("المظهر الداكن", "Dark appearance"), tr("هدوء أكثر للعين", "A little easier on the eyes"), { SadaStore.update { it.copy(dark = !it.dark) } }, trailing = { Switch(data.dark, { value -> SadaStore.update { it.copy(dark = value) } }) })
            }
        }
        item {
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) { IconTile(Icons.Outlined.Tune); Spacer(Modifier.width(12.dp)); Text(tr("سلوك الوكيل", "Assistant behavior"), fontWeight = FontWeight.Bold) }
                Spacer(Modifier.height(14.dp))
                Text(tr("انتظار استقرار الرسائل", "Message settling time"), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Slider(value = delay, onValueChange = { delay = it }, onValueChangeFinished = { SadaStore.update { it.copy(delayMs = delay.toLong()) } }, valueRange = 1200f..6000f, steps = 23, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(10.dp))
                    Text(String.format(java.util.Locale.US, "%.1f", delay / 1000) + tr(" ث", " s"), fontSize = 13.sp)
                }
                Text(tr("يُعاد الانتظار عند وصول تحديث. مؤشر «يكتب» يؤخر الرد أيضاً. هذا يقلل المقاطعة لكنه لا يضمن معرفة متى انتهى الطرف الآخر تماماً.", "New activity resets the wait. A visible typing indicator also delays the reply. This reduces interruptions but cannot guarantee the other person has finished."), fontSize = 11.sp, lineHeight = 21.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(15.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                InfoRow(Icons.Outlined.AutoAwesome, tr("توقيع المساعد", "Assistant disclosure"), tr("يوضّح أن الرد أُرسل بمساعدة صدى", "Makes assistant-generated replies clear"), { SadaStore.update { it.copy(disclose = !it.disclose) } }, trailing = { Switch(data.disclose, { value -> SadaStore.update { it.copy(disclose = value) } }) })
            }
        }
        item {
            Panel {
                SectionTitle(tr("الخصوصية والنشاط", "PRIVACY & ACTIVITY"))
                InfoRow(Icons.Outlined.History, tr("سجل النشاط", "Activity log"), tr("أحداث التشغيل، دون نصوص المحادثات", "Operational events, not conversation content"), onActivity)
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                InfoRow(Icons.Outlined.Shield, tr("إلغاء موافقة التشغيل", "Revoke automation consent"), tr("إيقاف فوري لجميع الجلسات", "Immediately stops all sessions"), { SadaAgentService.stopSession(); SadaStore.update { it.copy(consent = false) }; notify(data.word("أُلغيت الموافقة. يمكنك تعطيل الخدمة أيضاً من إعدادات النظام.", "Consent revoked. You can also disable the service in system settings.")) })
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                InfoRow(Icons.Outlined.DeleteOutline, tr("حذف بياناتي المحلية", "Delete my local data"), tr("المفتاح، الشخصية، الذاكرة والسجل", "Key, persona, memories and activity"), { erase = true })
            }
        }
        item {
            Panel { InfoRow(Icons.Outlined.Info, tr("عن صدى", "About Sada"), tr("وكيلك الشخصي • الإصدار 1.0", "Your personal assistant · Version 1.0"), { about = true }) }
        }
        item { Text(tr("صُنع ليمنحك وقتاً أكثر، لا ليتخذ قراراتك.", "Made to give you time back, not take your choices away."), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(6.dp)) }
    }
    if (erase) AlertDialog(onDismissRequest = { erase = false }, title = { Text(tr("حذف جميع البيانات؟", "Delete all local data?")) }, text = { Text(tr("لا يمكن التراجع عن هذا الإجراء. ستتوقف الجلسة وتُحذف بيانات صدى من الجهاز. لا يحذف هذا بيانات أرسلت سابقاً إلى Google أو تطبيقات المحادثة.", "This cannot be undone. The session stops and Sada data is removed from this device. Data already sent to Google or chat apps is not deleted.")) }, confirmButton = { TextButton(onClick = { SadaAgentService.stopSession(); SadaStore.clear(); erase = false; notify(data.word("تم حذف البيانات المحلية", "Local data deleted")) }) { Text(tr("حذف الكل", "Delete everything"), color = MaterialTheme.colorScheme.error) } }, dismissButton = { TextButton(onClick = { erase = false }) { Text(tr("إلغاء", "Cancel")) } })
    if (about) AlertDialog(onDismissRequest = { about = false }, icon = { Icon(Icons.Outlined.GraphicEq, null) }, title = { Text(tr("صدى · امتدادٌ لشخصيتك", "Sada · Naturally, you")) }, text = { Text(tr("تطبيق أندرويد أصلي بلوحة مفاتيح عربية وإنجليزية، ذاكرة محلية مشفرة واتصال مباشر بـ Gemini. التشغيل التلقائي مقيد بمحادثة تختارها ومعايرة واضحة. لا توجد قراءة للشاشة خارج الجلسة إلا عند ضغط المعايرة.\n\nلا يوجد اختبار فعلي لمفتاح دون إدخاله، ولا ضمان لدقة الذكاء الاصطناعي أو توافق جميع التطبيقات. اختبر في محادثة تجريبية أولاً.\n\nخط الواجهة: Cairo، بترخيص SIL Open Font License.", "A native Android app with Arabic and English keyboards, encrypted local memory and direct Gemini access. Automation is limited to a chosen, calibrated conversation. Outside a session, the screen is read only when you tap Calibrate.\n\nA live key test requires your key. AI accuracy and compatibility with every app cannot be guaranteed. Start in a test conversation.\n\nInterface font: Cairo, SIL Open Font License."), fontSize = 12.sp) }, confirmButton = { TextButton(onClick = { about = false }) { Text(tr("فهمت", "Got it")) } })
}
