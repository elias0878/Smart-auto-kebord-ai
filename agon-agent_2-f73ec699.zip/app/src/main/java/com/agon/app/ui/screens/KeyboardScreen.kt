package com.agon.app.ui.screens

import android.content.Intent
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.agon.app.data.AppData
import com.agon.app.data.SadaStore
import com.agon.app.data.word
import com.agon.app.service.AgentStatus
import com.agon.app.service.SadaAgentService
import com.agon.app.ui.components.*

@Composable fun KeyboardScreen(data: AppData, status: AgentStatus, notify: (String) -> Unit) {
    val context = LocalContext.current
    val imm = context.getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as InputMethodManager
    var keyboardEnabled by remember { mutableStateOf(imm.enabledInputMethodList.any { it.packageName == context.packageName }) }
    var disclosure by remember { mutableStateOf(false) }
    var practice by remember { mutableStateOf("") }
    val lifecycle = LocalLifecycleOwner.current
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_RESUME) keyboardEnabled = imm.enabledInputMethodList.any { it.packageName == context.packageName } }
        lifecycle.lifecycle.addObserver(observer)
        onDispose { lifecycle.lifecycle.removeObserver(observer) }
    }
    fun openSetting(action: String) {
        runCatching { context.startActivity(Intent(action)) }.onFailure { notify(data.word("افتح إعدادات النظام يدوياً", "Open system settings manually")) }
    }
    LazyColumn(contentPadding = PaddingValues(22.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item { PageTitle(tr("بين يديك", "RIGHT AT YOUR FINGERTIPS"), tr("لوحة مفاتيح. ووكيل.", "A keyboard. And an assistant."), tr("اكتب بنفسك، أو دع صدى يرد في المحادثة التي تختارها. تحكّم كامل بنقرة.", "Type yourself, or let Sada reply in a conversation you choose. One tap puts you in control.")) }
        item {
            Surface(shape = RoundedCornerShape(25.dp), color = Forest, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Keyboard, null, tint = Lime, modifier = Modifier.size(29.dp)); Spacer(Modifier.width(12.dp))
                        Text(tr("لوحة صدى الذكية", "Sada Smart Keyboard"), color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold)
                    }
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp)).background(androidx.compose.ui.graphics.Color.White.copy(alpha = .08f)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(tr("صدى", "sada"), color = Lime, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(tr("معايرة", "Calibrate"), color = androidx.compose.ui.graphics.Color(0xFFCEDECA), fontSize = 11.sp)
                        Spacer(Modifier.width(12.dp))
                        SmallTag(tr("▶ تلقائي", "▶ Auto"), Lime, Forest)
                    }
                    Text(tr("شريط التحكم الذي يرافقك داخل المحادثة", "Your assistant controls, right inside the conversation"), color = androidx.compose.ui.graphics.Color(0xFFB7CABC), fontSize = 11.sp)
                }
            }
        }
        item {
            Panel {
                SectionTitle(tr("إعداد لمرة واحدة", "ONE-TIME SETUP"))
                Spacer(Modifier.height(8.dp))
                InfoRow(Icons.Outlined.Keyboard, tr("تفعيل لوحة صدى", "Enable Sada Keyboard"), if (keyboardEnabled) tr("مفعّلة في إعدادات النظام", "Enabled in system settings") else tr("أضف صدى إلى لوحات الإدخال", "Add Sada to your input methods"), { openSetting(Settings.ACTION_INPUT_METHOD_SETTINGS) }, trailing = { if (keyboardEnabled) Icon(Icons.Outlined.CheckCircle, null, tint = MaterialTheme.colorScheme.primary) else SmallTag(tr("تفعيل", "Enable")) })
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                InfoRow(Icons.Outlined.TouchApp, tr("اختيار لوحة المفاتيح", "Choose your keyboard"), tr("انتقل إلى صدى بنقرة", "Switch to Sada in one tap"), { if (keyboardEnabled) imm.showInputMethodPicker() else notify(data.word("فعّل لوحة صدى أولاً", "Enable Sada Keyboard first")) })
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                InfoRow(Icons.Outlined.AccessibilityNew, tr("قراءة المحادثة والتحكم", "Read & interact with chats"), if (status.connected) tr("خدمة الوصول متصلة", "Accessibility service connected") else tr("يتطلب موافقتك وإذن النظام", "Requires your consent and system permission"), { disclosure = true }, trailing = { if (status.connected) Icon(Icons.Outlined.CheckCircle, null, tint = MaterialTheme.colorScheme.primary) else SmallTag(tr("مراجعة", "Review")) })
            }
        }
        item {
            Panel {
                Text(tr("كيف تبدأ محادثتك الأولى؟", "Start your first conversation"), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(Modifier.height(12.dp))
                val steps = listOf(
                    tr("افحص مفتاح Gemini والنموذج المختار من شاشة الاتصال.", "Inspect your Gemini key and test the selected model in Connection."),
                    tr("افتح محادثة فردية فيها رسائل منك ومن الطرف الآخر، ثم أظهر لوحة صدى.", "Open a one-to-one chat with messages from both sides, then show Sada Keyboard."),
                    tr("اضغط «معايرة» وحدد رسالة واردة ورسالة منك. يجب أن تكونا على جهتين مختلفتين.", "Tap Calibrate and mark an incoming message and one of yours. They must be on opposite sides."),
                    tr("فعّل «تلقائي». يبدأ الرد على الرسائل الجديدة فقط، بعد استقرار السياق.", "Enable Auto. Only new incoming messages are answered, after the conversation settles.")
                )
                steps.forEachIndexed { index, label ->
                    Row(Modifier.padding(vertical = 7.dp), verticalAlignment = Alignment.Top) {
                        SmallTag("${index + 1}")
                        Spacer(Modifier.width(10.dp))
                        Text(label, fontSize = 12.sp, lineHeight = 23.sp, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
        item {
            Panel {
                Text(tr("جرّب الكتابة هنا", "Try typing here"), fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(practice, { practice = it.take(2000) }, modifier = Modifier.fillMaxWidth(), minLines = 2, shape = RoundedCornerShape(14.dp), placeholder = { Text(tr("اضغط لإظهار لوحة المفاتيح…", "Tap to open the keyboard…"), fontSize = 12.sp) })
                Text(tr("هذا الحقل للكتابة اليدوية فقط، وليس للتشغيل التلقائي.", "This field is for manual typing, not automatic sessions."), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item { Notice(tr("الأمان قبل الإرسال: يتوقف صدى عند إغلاق اللوحة، تغيير المحادثة، بدء الكتابة اليدوية، أو غموض الاتجاه أو زر الإرسال. لا يدعم الصور والصوت والمجموعات بشكل موثوق، ولا يمكن ضمان التوافق مع كل تطبيق.", "Safety before sending: Sada stops when the keyboard closes, the conversation changes, you type manually, or message direction or Send is unclear. Images, audio and groups are not reliably supported. Compatibility with every app cannot be guaranteed.")) }
        if (status.active) item { PrimaryButton(tr("إيقاف الجلسة الآن", "Stop the session now"), { SadaAgentService.stopSession() }) }
    }
    if (disclosure) AlertDialog(
        onDismissRequest = { disclosure = false },
        icon = { Icon(Icons.Outlined.PrivacyTip, null) },
        title = { Text(tr("إذن واضح. وتحكّم كامل.", "Your permission. Your control.")) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(tr("تتيح خدمة الوصول لصدى قراءة النص الظاهر في المحادثة المختارة، تحديد حقل الكتابة، إدخال الرد والضغط على إرسال نيابةً عنك.", "Accessibility lets Sada read visible text in your selected chat, find the input field, insert a reply and press Send on your behalf."), fontSize = 13.sp)
            Text(tr("عند تفعيل جلسة من لوحة صدى، تُرسل الرسائل الظاهرة وشخصيتك وذكرياتك ذات الصلة إلى Google Gemini. لا تُحفظ المحادثات في سجل التطبيق. يجب أن تكون مخوّلاً بمشاركة المحادثة، وألا تستخدمه للخداع أو في قرارات حساسة.", "When you start a session from Sada Keyboard, visible messages, your persona and relevant memories are sent to Google Gemini. Conversations are not stored in the activity log. You must be authorized to share the conversation. Do not use it for deception or sensitive decisions."), fontSize = 12.sp)
            Text(tr("لا يبدأ الرد بمجرد منح الإذن؛ تختار المحادثة وتعايرها وتفعّلها بنفسك. يمكنك إيقافه في أي وقت.", "Granting permission does not start replies. You choose, calibrate and enable the conversation yourself. You can stop at any time."), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        } },
        confirmButton = { TextButton(onClick = { SadaStore.update { it.copy(consent = true) }; disclosure = false; openSetting(Settings.ACTION_ACCESSIBILITY_SETTINGS) }) { Text(tr("أوافق، افتح إعدادات الوصول", "I agree · Open accessibility")) } },
        dismissButton = { TextButton(onClick = { disclosure = false }) { Text(tr("ليس الآن", "Not now")) } }
    )
}
