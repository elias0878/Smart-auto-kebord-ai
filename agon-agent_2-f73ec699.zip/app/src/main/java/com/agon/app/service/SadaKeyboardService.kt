package com.agon.app.service

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.agon.app.MainActivity
import com.agon.app.data.SadaStore
import kotlinx.coroutines.*

class SadaKeyboardService : InputMethodService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var root: LinearLayout? = null
    private var statusText: TextView? = null
    private var autoButton: Button? = null
    private var arabic = true
    private var dark = false
    private var lettersArabic = true
    private var symbols = false
    private var caps = false
    private var calibrating = false
    private var password = false
    private var savedSnapshot: ChatSnapshot? = null
    private val forest = Color.rgb(24, 62, 49)
    private val lime = Color.rgb(195, 242, 139)
    private val gray = Color.rgb(236, 240, 232)
    private fun text(ar: String, en: String) = if (arabic) ar else en
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    override fun onCreate() {
        super.onCreate()
        SadaStore.init(applicationContext)
        arabic = SadaStore.state.value.arabic
        dark = SadaStore.state.value.dark
        lettersArabic = arabic
        scope.launch { SadaStore.state.collect { data -> if (arabic != data.arabic || dark != data.dark) { arabic = data.arabic; dark = data.dark; render() } } }
        scope.launch { SadaAgentService.status.collect { s ->
            statusText?.text = if (arabic) s.ar else s.en
            autoButton?.text = if (s.active) text("■ إيقاف", "■ Stop") else text("▶ تلقائي", "▶ Auto")
        } }
    }
    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(5), dp(8), dp(5), dp(12)); setBackgroundColor(Color.rgb(246, 247, 242)) }
        render()
        return root!!
    }
    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val variation = (info?.inputType ?: 0) and android.text.InputType.TYPE_MASK_VARIATION
        password = variation in setOf(android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD, android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD, android.text.InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD, android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        calibrating = false
        if (password) SadaAgentService.stopSession()
        render()
    }
    override fun onFinishInputView(finishingInput: Boolean) {
        SadaAgentService.instance?.stop("أُغلقت لوحة المفاتيح؛ توقفت الجلسة", "Keyboard closed; session stopped")
        super.onFinishInputView(finishingInput)
    }
    override fun onDestroy() { scope.cancel(); super.onDestroy() }
    private fun shape(color: Int, radius: Int = 10) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun button(label: String, weight: Float = 1f, accent: Boolean = false, action: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 14f; isAllCaps = false; setTextColor(if (dark && !accent) Color.rgb(237, 244, 230) else forest); minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
        setPadding(0, 0, 0, 0); background = shape(if (accent) lime else if (dark) Color.rgb(41, 58, 48) else Color.WHITE)
        layoutParams = LinearLayout.LayoutParams(0, dp(43), weight).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }
        setOnClickListener { performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP); action() }
    }
    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; layoutDirection = View.LAYOUT_DIRECTION_LTR }
    private fun note(value: String, size: Float = 11f) = TextView(this).apply { text = value; textSize = size; setTextColor(if (dark) Color.rgb(220, 234, 215) else forest); gravity = Gravity.CENTER; setPadding(dp(8), dp(7), dp(8), dp(7)) }
    private fun toast(value: String) = Toast.makeText(this, value, Toast.LENGTH_LONG).show()
    private fun manual(value: String) { SadaAgentService.stopSession(); currentInputConnection?.commitText(value, 1) }
    private fun render() {
        val container = root ?: return
        container.removeAllViews()
        container.setBackgroundColor(if (dark) Color.rgb(20, 32, 25) else Color.rgb(246, 247, 242))
        container.layoutDirection = if (arabic) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        val status = SadaAgentService.status.value
        val top = row()
        top.addView(button("⚙", .65f) { startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("page", 2)) })
        top.addView(button(text("معايرة", "Calibrate"), 1.3f) {
            if (password) { toast(text("المساعد معطّل في حقول كلمات المرور", "Assistant is disabled in password fields")); return@button }
            val agent = SadaAgentService.instance
            if (agent == null) { toast(text("فعّل خدمة الوصول من التطبيق أولاً", "Enable accessibility in Sada first")); return@button }
            savedSnapshot = agent.capture()
            if (savedSnapshot == null || savedSnapshot!!.bubbles.isEmpty()) toast(text("لا يمكن قراءة هذه المحادثة بأمان. جرّب محادثة نصية تحتوي رسائل من الطرفين.", "Cannot safely read this chat. Open a text conversation with messages from both sides."))
            else { calibrating = !calibrating; render() }
        })
        autoButton = button(if (status.active) text("■ إيقاف", "■ Stop") else text("▶ تلقائي", "▶ Auto"), 1.5f, true) {
            if (SadaAgentService.status.value.active) SadaAgentService.stopSession()
            else if (password) toast(text("المساعد معطّل هنا", "Assistant is disabled here"))
            else {
                val agent = SadaAgentService.instance
                if (agent == null) toast(text("فعّل خدمة الوصول أولاً", "Enable accessibility first"))
                else agent.startSession()?.let(::toast) ?: run { calibrating = false; render() }
            }
        }
        top.addView(autoButton)
        top.addView(note(text("صدى", "sada"), 19f).apply { typeface = Typeface.DEFAULT_BOLD; layoutParams = LinearLayout.LayoutParams(0, dp(46), .85f) })
        container.addView(top)
        statusText = note(if (arabic) status.ar else status.en)
        container.addView(statusText)
        if (calibrating) {
            container.addView(note(text("اختر رسالة واردة وأخرى منك، ثم فعّل التلقائي.\nتعمل المعايرة لهذه المحادثة فقط؛ راجع الاتجاه جيداً.", "Mark one incoming message and one of yours, then enable Auto.\nCalibration is only for this chat. Verify the sides carefully.")))
            container.addView(note(SadaAgentService.instance?.calibrationLabel(arabic).orEmpty()))
            val scroll = ScrollView(this)
            val choices = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val snapshot = savedSnapshot
            snapshot?.bubbles?.takeLast(10)?.forEach { bubble ->
                choices.addView(note(bubble.text.take(140), 13f))
                val r = row()
                fun mark(incoming: Boolean) {
                    val result = SadaAgentService.instance?.calibrate(snapshot, bubble, incoming)
                    if (result != null) toast(text("الرسالة غير واضحة أو تغيّرت الشاشة؛ أعد المعايرة", "Message is ambiguous or screen changed; recalibrate"))
                    render()
                }
                r.addView(button(text("من الطرف الآخر", "Incoming")) { mark(true) })
                r.addView(button(text("هذه رسالتي", "This is mine")) { mark(false) })
                choices.addView(r)
            }
            scroll.addView(choices)
            container.addView(scroll, LinearLayout.LayoutParams(-1, dp(120)))
            val close = row(); close.addView(button(text("العودة للكتابة", "Back to typing"), accent = true) { calibrating = false; render() }); container.addView(close)
            return
        }
        val rows = if (symbols) listOf("1 2 3 4 5 6 7 8 9 0", "@ # $ % & * - + ( )", "! ؟ ? ، , . : / \"")
            else if (lettersArabic) listOf("ض ص ث ق ف غ ع ه خ ح ج", "ش س ي ب ل ا ت ن م ك ط", "ئ ء ؤ ر ى ة و ز ظ د ذ")
            else listOf("q w e r t y u i o p", "a s d f g h j k l", "z x c v b n m")
        rows.forEachIndexed { index, letters ->
            val r = row()
            if (!lettersArabic && !symbols && index == 2) r.addView(button("⇧", 1.2f) { caps = !caps; render() })
            letters.split(" ").forEach { letter ->
                val key = if (caps && !lettersArabic) letter.uppercase() else letter
                val b = button(key) { manual(key) }
                if (letter == "ا") b.setOnLongClickListener { manual("أ"); true }
                if (letter == "ي") b.setOnLongClickListener { manual("ى"); true }
                if (letter == "ه") b.setOnLongClickListener { manual("ة"); true }
                r.addView(b)
            }
            if (index == 2) {
                val delete = button("⌫", 1.2f) { SadaAgentService.stopSession(); currentInputConnection?.deleteSurroundingText(1, 0) }
                delete.setOnLongClickListener { SadaAgentService.stopSession(); currentInputConnection?.deleteSurroundingText(40, 0); true }
                r.addView(delete)
            }
            container.addView(r)
        }
        val bottom = row()
        bottom.addView(button(if (symbols) text("أبج", "ABC") else "?123", 1.2f) { symbols = !symbols; render() })
        val language = button(if (lettersArabic) "EN" else "ع", 1f) { lettersArabic = !lettersArabic; symbols = false; render() }
        language.setOnLongClickListener { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker(); true }
        bottom.addView(language)
        bottom.addView(button("🌐", .8f) { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() })
        bottom.addView(button(text("مسافة", "space"), 3.5f) { manual(" ") })
        bottom.addView(button("↵", 1.3f, true) {
            SadaAgentService.stopSession()
            val options = currentInputEditorInfo?.imeOptions ?: 0
            val action = options and EditorInfo.IME_MASK_ACTION
            if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED && options and EditorInfo.IME_FLAG_NO_ENTER_ACTION == 0) currentInputConnection?.performEditorAction(action)
            else currentInputConnection?.commitText("\n", 1)
        })
        container.addView(bottom)
    }
}
