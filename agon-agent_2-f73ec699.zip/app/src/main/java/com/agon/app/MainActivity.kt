package com.agon.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.navigation.compose.*
import com.agon.app.data.AppData
import com.agon.app.data.SadaStore
import com.agon.app.service.SadaAgentService
import com.agon.app.ui.components.*
import com.agon.app.ui.screens.*
import com.agon.app.ui.theme.AgonAppTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        SadaStore.init(applicationContext)
        setContent {
            val data by SadaStore.state.collectAsState()
            SideEffect {
                WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightStatusBars = !data.dark
                WindowCompat.getInsetsController(window, window.decorView).isAppearanceLightNavigationBars = !data.dark
            }
            CompositionLocalProvider(LocalArabic provides data.arabic, LocalLayoutDirection provides if (data.arabic) LayoutDirection.Rtl else LayoutDirection.Ltr) {
                AgonAppTheme(darkTheme = data.dark) { SadaApp(data, intent.getIntExtra("page", 0)) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun SadaApp(data: AppData, initialPage: Int) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val routes = listOf("home", "persona", "keyboard", "connection", "preferences")
    val status by SadaAgentService.status.collectAsState()
    val storageError by SadaStore.storageError.collectAsState()
    var setup by remember { mutableStateOf(false) }
    var preview by remember { mutableStateOf(false) }
    var activity by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val notify: (String) -> Unit = { message -> scope.launch { snackbar.showSnackbar(message) }; Unit }
    fun navigate(index: Int) {
        setup = false
        nav.navigate(routes[index.coerceIn(0, 4)]) { popUpTo("home") { saveState = true }; launchSingleTop = true; restoreState = true }
    }
    LaunchedEffect(initialPage) { if (initialPage != 0) navigate(initialPage) }
    val labels = listOf(tr("الرئيسية", "Home"), tr("شخصيتي", "Persona"), tr("لوحتي", "Keyboard"), tr("الاتصال", "Connect"), tr("الإعدادات", "Settings"))
    val icons = listOf(Icons.Outlined.SpaceDashboard, Icons.Outlined.Fingerprint, Icons.Outlined.Keyboard, Icons.Outlined.AutoAwesome, Icons.Outlined.Tune)
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            Surface(color = MaterialTheme.colorScheme.surface) {
                Column {
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant, thickness = .6.dp)
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 0.dp, modifier = Modifier.height(84.dp)) {
                        routes.forEachIndexed { index, route ->
                            NavigationBarItem(selected = (backStack?.destination?.route ?: "home") == route, onClick = { navigate(index) },
                                icon = { Icon(icons[index], labels[index], modifier = Modifier.size(23.dp)) },
                                label = { Text(labels[index], fontSize = 9.sp, fontWeight = if (backStack?.destination?.route == route) FontWeight.Bold else FontWeight.Normal, maxLines = 1) },
                                colors = NavigationBarItemDefaults.colors(selectedIconColor = Forest, selectedTextColor = MaterialTheme.colorScheme.primary, indicatorColor = Lime.copy(alpha = .55f), unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant, unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant))
                        }
                    }
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (storageError) Notice(tr("تعذّر فتح التخزين المشفر أو حفظ البيانات. لا تعتمد على استمرارها حتى حل المشكلة.", "Encrypted storage could not be opened or saved. Do not rely on persistence until this is resolved."), true)
            NavHost(navController = nav, startDestination = "home", modifier = Modifier.weight(1f)) {
                composable("home") { Dashboard(data, status.active, ::navigate, { setup = true }, { preview = true }, { activity = true }, { SadaAgentService.stopSession() }) }
                composable("persona") { PersonaScreen(data, notify) }
                composable("keyboard") { KeyboardScreen(data, status, notify) }
                composable("connection") { ConnectionScreen(data, notify) }
                composable("preferences") { PreferencesScreen(data, { activity = true }, notify) }
            }
        }
    }
    if (setup) ModalBottomSheet(onDismissRequest = { setup = false }, containerColor = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 22.dp).padding(bottom = 30.dp)) {
            PageTitle(tr("لنبدأ معاً", "LET’S GET YOU READY"), tr("ثلاث خطوات. وصدى جاهز.", "Three steps. Then you’re ready."), tr("لن يُرسل أي رد قبل أن تختار محادثة وتفعّلها من لوحة المفاتيح.", "Nothing is sent until you choose a chat and enable a session from the keyboard."))
            InfoRow(Icons.Outlined.AutoAwesome, tr("١. اربط Gemini", "1. Connect Gemini"), tr("احفظ مفتاحك واختبر نموذجك", "Save your key and test your model"), { navigate(3) })
            InfoRow(Icons.Outlined.Fingerprint, tr("٢. أضف شخصيتك", "2. Add your persona"), tr("أسلوبك، لهجتك والتفاصيل المهمة", "Your style, dialect and the details that matter"), { navigate(1) })
            InfoRow(Icons.Outlined.Keyboard, tr("٣. فعّل لوحة صدى", "3. Enable Sada Keyboard"), tr("امنح الأذونات ثم عاير محادثتك", "Grant permissions, then calibrate a chat"), { navigate(2) })
            Spacer(Modifier.height(14.dp))
            Notice(tr("يمكن أن يخطئ الذكاء الاصطناعي. ابدأ بمحادثة تجريبية وتجنب المحادثات الحساسة.", "AI can make mistakes. Start with a test conversation and avoid sensitive chats."))
        }
    }
    if (preview) ConversationLab(data, { preview = false }, { preview = false; navigate(3) })
    if (activity) ActivitySheet(data, { activity = false })
}
