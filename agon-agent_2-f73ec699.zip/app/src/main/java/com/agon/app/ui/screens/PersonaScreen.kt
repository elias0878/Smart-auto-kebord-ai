package com.agon.app.ui.screens

import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.*
import com.agon.app.ui.components.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun PersonaScreen(data: AppData, notify: (String) -> Unit) {
    var section by rememberSaveable { mutableIntStateOf(0) }
    var name by remember(data.name) { mutableStateOf(data.name) }
    var persona by remember(data.persona) { mutableStateOf(data.persona) }
    var tone by rememberSaveable { mutableStateOf(data.tone) }
    var editing by remember { mutableStateOf<Memory?>(null) }
    var adding by remember { mutableStateOf(false) }
    var delete by remember { mutableStateOf<Memory?>(null) }
    var importing by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            importing = true
            try {
                val imported = withContext(Dispatchers.IO) {
                    val title = context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null } ?: "Memory.txt"
                    val body = context.contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { reader ->
                        val builder = StringBuilder(); val buffer = CharArray(4096)
                        while (true) {
                            val count = reader.read(buffer)
                            if (count < 0) break
                            builder.append(buffer, 0, count)
                            if (builder.length > 200000) throw IllegalArgumentException(data.word("الحد الأقصى 200 ألف حرف لكل ملف", "Maximum 200,000 characters per file"))
                        }
                        builder.toString()
                    } ?: error("Unable to read file")
                    require(body.isNotBlank()) { data.word("الملف فارغ", "The file is empty") }
                    Memory(title = title.removeSuffix(".txt"), body = body, category = "document")
                }
                if (data.memories.size >= 50) throw IllegalArgumentException(data.word("الحد الأقصى 50 مستنداً", "Maximum 50 documents"))
                SadaStore.update { it.copy(memories = it.memories + imported) }
                notify(data.word("تم استيراد الذاكرة وتشفيرها", "Memory imported and encrypted"))
            } catch (e: Exception) { notify(e.message ?: data.word("تعذّر قراءة الملف", "Could not read file")) }
            finally { importing = false }
        }
    }
    LazyColumn(contentPadding = PaddingValues(22.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item { PageTitle(tr("بصمتك الخاصة", "YOUR DISTINCTIVE VOICE"), tr("يشبهك في كل كلمة", "Unmistakably you"), tr("عرّف صدى على أسلوبك، ودعه يفهم التفاصيل التي تصنع شخصيتك.", "Give Sada your voice and the details that make you, you.")) }
        item {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(selected = section == 0, onClick = { section = 0 }, shape = SegmentedButtonDefaults.itemShape(0, 2)) { Text(tr("الشخصية", "Persona")) }
                SegmentedButton(selected = section == 1, onClick = { section = 1 }, shape = SegmentedButtonDefaults.itemShape(1, 2)) { Text(tr("الذاكرة", "Memory") + " · ${data.memories.size}") }
            }
        }
        if (section == 0) {
            item {
                Panel {
                    Row(verticalAlignment = Alignment.CenterVertically) { IconTile(Icons.Outlined.Fingerprint); Spacer(Modifier.width(12.dp)); Text(tr("لنبدأ بك", "Start with you"), fontWeight = FontWeight.Bold) }
                    Spacer(Modifier.height(18.dp))
                    OutlinedTextField(name, { name = it.take(60) }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text(tr("بماذا يناديك الآخرون؟", "What do people call you?")) }, shape = RoundedCornerShape(14.dp))
                    Spacer(Modifier.height(15.dp))
                    OutlinedTextField(persona, { persona = it.take(12000) }, modifier = Modifier.fillMaxWidth().heightIn(min = 200.dp), minLines = 6, label = { Text(tr("صِف شخصيتك وأسلوبك", "Describe your persona")) }, placeholder = { Text(tr("أحب الردود المختصرة والدافئة. أتكلم باللهجة السعودية، وأستخدم الإيموجي باعتدال. لا أحب المبالغة…", "I like warm, concise replies. I write casually, use emojis sparingly, and avoid overpromising…"), fontSize = 13.sp) }, shape = RoundedCornerShape(14.dp), supportingText = { Text("${persona.length} / 12000", fontSize = 10.sp) })
                    TextButton(onClick = { persona = data.word("أتحدث بأسلوب ودود وطبيعي وبلهجة عربية بسيطة. ردودي قصيرة وواضحة، وأستخدم الإيموجي باعتدال. أستمع جيداً وأطرح سؤالاً إذا لم أفهم. لا أقطع وعوداً أو أشارك معلومات خاصة دون إذن.", "I speak warmly and naturally, with clear, concise replies. I use emojis sparingly, listen carefully and ask when I am unsure. I do not make promises or share private information without permission.") }) { Icon(Icons.Outlined.AutoAwesome, null, Modifier.size(16.dp)); Spacer(Modifier.width(7.dp)); Text(tr("ابدأ بوصف مقترح", "Use a starting point"), fontSize = 12.sp) }
                }
            }
            item {
                Panel {
                    Text(tr("نبرة الردود", "Reply tone"), fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        listOf("friendly" to tr("ودود", "Warm"), "casual" to tr("عفوي", "Casual"), "professional" to tr("مهني", "Professional")).forEach { (id, label) ->
                            FilterChip(selected = tone == id, onClick = { tone = id }, label = { Text(label, fontSize = 12.sp) })
                        }
                    }
                }
            }
            item { PrimaryButton(tr("حفظ شخصيتي", "Save my persona"), { SadaStore.update { it.copy(name = name.trim(), persona = persona.trim(), tone = tone) }; notify(data.word("تم حفظ شخصيتك", "Your persona is saved")) }) }
        } else {
            item {
                Panel {
                    IconTile(Icons.Outlined.AutoStories)
                    Spacer(Modifier.height(14.dp))
                    Text(tr("تفاصيل صغيرة. فهم أعمق.", "Small details. Deeper understanding."), fontWeight = FontWeight.Bold)
                    Text(tr("أضف معلومات عن عملك وعلاقاتك وتفضيلاتك. تُختار المقاطع ذات الصلة بالسياق وتُرسل إلى Gemini، لا مكتبتك كاملة.", "Add your work, relationships and preferences. Relevant excerpts are selected and sent to Gemini, not your entire library."), fontSize = 12.sp, lineHeight = 23.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(14.dp))
                    PrimaryButton(tr("إضافة ذكرى", "Add a memory"), { adding = true }, enabled = data.memories.size < 50)
                    TextButton(onClick = { importer.launch(arrayOf("text/plain")) }, enabled = !importing && data.memories.size < 50, modifier = Modifier.fillMaxWidth()) {
                        if (importing) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp) else Icon(Icons.Outlined.UploadFile, null, Modifier.size(19.dp))
                        Spacer(Modifier.width(8.dp)); Text(tr("استيراد ملف نصي TXT", "Import a TXT document"), fontSize = 12.sp)
                    }
                    Text(tr("حتى 50 مستنداً • 200 ألف حرف للمستند", "Up to 50 documents · 200,000 characters each"), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (data.memories.isEmpty()) item { Notice(tr("ذاكرتك تبدأ هنا. أضف أول تفصيل ترغب أن يتذكره صدى عنك.", "Your memory starts here. Add the first thing you want Sada to remember.")) }
            items(data.memories, key = { it.id }) { memory ->
                Panel {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconTile(Icons.Outlined.Description, size = 38)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f).clickable { editing = memory }) {
                            Text(memory.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(tr("${memory.body.length} حرف", "${memory.body.length} characters"), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { editing = memory }) { Icon(Icons.Outlined.Edit, tr("تعديل", "Edit"), Modifier.size(20.dp)) }
                        IconButton(onClick = { delete = memory }) { Icon(Icons.Outlined.DeleteOutline, tr("حذف", "Delete"), Modifier.size(20.dp)) }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(memory.body.take(170), fontSize = 12.sp, maxLines = 3, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item { Notice(tr("خصوصيتك أولاً: تُشفّر الشخصية والذاكرة محلياً باستخدام Android Keystore. لا تضف كلمات مرور أو بيانات مالية حساسة.", "Privacy first: your persona and memories are encrypted locally using Android Keystore. Do not add passwords or sensitive financial data.")) }
    }
    if (adding || editing != null) {
        val existing = editing
        var title by remember(existing?.id) { mutableStateOf(existing?.title ?: "") }
        var body by remember(existing?.id) { mutableStateOf(existing?.body ?: "") }
        ModalBottomSheet(onDismissRequest = { adding = false; editing = null }, containerColor = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxWidth().padding(22.dp).imePadding(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Text(tr("مساحة للتفاصيل", "Room for the details"), fontSize = 23.sp, fontWeight = FontWeight.Bold)
                OutlinedTextField(title, { title = it.take(100) }, label = { Text(tr("عنوان الذكرى", "Memory title")) }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp))
                OutlinedTextField(body, { body = it.take(200000) }, label = { Text(tr("ما الذي تريد أن يتذكره؟", "What should Sada remember?")) }, modifier = Modifier.fillMaxWidth().heightIn(min = 170.dp, max = 280.dp), minLines = 5, shape = RoundedCornerShape(14.dp))
                PrimaryButton(tr("حفظ في الذاكرة", "Save to memory"), {
                    val memory = Memory(id = existing?.id ?: java.util.UUID.randomUUID().toString(), title = title.trim(), body = body.trim())
                    SadaStore.update { it.copy(memories = if (existing == null) it.memories + memory else it.memories.map { m -> if (m.id == existing.id) memory else m }) }
                    adding = false; editing = null
                    notify(data.word("تم حفظ الذكرى", "Memory saved"))
                }, enabled = title.isNotBlank() && body.isNotBlank())
                Spacer(Modifier.height(12.dp))
            }
        }
    }
    delete?.let { memory ->
        AlertDialog(onDismissRequest = { delete = null }, title = { Text(tr("حذف الذكرى؟", "Delete memory?")) }, text = { Text(memory.title) }, confirmButton = { TextButton(onClick = { SadaStore.update { it.copy(memories = it.memories.filterNot { m -> m.id == memory.id }) }; delete = null }) { Text(tr("حذف", "Delete")) } }, dismissButton = { TextButton(onClick = { delete = null }) { Text(tr("إلغاء", "Cancel")) } })
    }
}
