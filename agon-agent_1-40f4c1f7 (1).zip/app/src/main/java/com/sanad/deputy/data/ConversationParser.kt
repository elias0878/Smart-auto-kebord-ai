package com.sanad.deputy.data

import android.graphics.Rect
import android.os.Build
import android.view.accessibility.AccessibilityNodeInfo
import java.lang.reflect.Method
import java.util.Locale

/**
 * Result of analysing the current window: a serialisable description for the UI plus
 * live node handles the agent needs in order to type and press "send".
 */
class ScreenAnalysis(
    val screen: ParsedScreen,
    val inputNode: AccessibilityNodeInfo?,
    val sendNode: AccessibilityNodeInfo?,
    val root: AccessibilityNodeInfo?
)

/**
 * Reads a chat screen from the accessibility tree.
 *
 * Everything is defensive: the tree can change under our feet at any moment
 * (screen rotation, a new message, the app being backgrounded) so every single
 * node access is guarded and the traversal is bounded in both depth and node count.
 */
object ConversationParser {

    /** Hard depth limit — protects against StackOverflowError on long conversations. */
    const val MAX_DEPTH = 25

    /** Hard node budget — protects against pathological trees. */
    const val MAX_NODES = 8000

    private const val MAX_CANDIDATES = 600

    /** A bubble hugs the trailing edge when its distance to it is below this share of the width. */
    private const val TRAILING_HUG_RATIO = 0.12f

    /** A bubble wider than this share of the screen is considered "full width" (ambiguous). */
    private const val FULL_WIDTH_RATIO = 0.86f

    private const val HEADER_RATIO = 0.18f

    // ------------------------------------------------------------------ noise

    private val dateTimePatterns = listOf(
        Regex("""^\s*[0-9٠-٩]{1,2}\s*[:.٫]\s*[0-9٠-٩]{2}\s*(AM|PM|am|pm|ص|م)?\s*$"""),
        Regex("""^\s*[0-9٠-٩]{1,2}\s*[/-]\s*[0-9٠-٩]{1,2}\s*[/-]\s*[0-9٠-٩]{1,4}\s*$"""),
        Regex("""^\s*(today|yesterday|tonight)\b.*$""", RegexOption.IGNORE_CASE),
        Regex("""^\s*(monday|tuesday|wednesday|thursday|friday|saturday|sunday|tue|wed|thu|fri|sat|sun)\b.*$""", RegexOption.IGNORE_CASE),
        Regex("""^\s*[0-9]{1,2}\s+(january|february|march|april|may|june|july|august|september|october|november|december)\b.*$""", RegexOption.IGNORE_CASE),
        Regex("""^\s*[0-9٠-٩]{1,2}\s+(يناير|فبراير|مارس|أبريل|ابريل|مايو|يونيو|يوليو|أغسطس|سبتمبر|أكتوبر|نوفمبر|ديسمبر)\b.*$"""),
        Regex("""^\s*(اليوم|أمس|امس|اليومِ|بارح)\s*$"""),
        Regex("""^\s*(الاثنين|الثلاثاء|الأربعاء|الخميس|الجمعة|السبت|الأحد|الأثنين|الإثنين)\b.*$""")
    )

    private val bannerPatterns = listOf(
        Regex("""end[- ]to[- ]end encrypted""", RegexOption.IGNORE_CASE),
        Regex("""messages and calls are encrypted""", RegexOption.IGNORE_CASE),
        Regex("""مشفرة من طرف إلى طرف"""),
        Regex("""الرسائل والمكالمات مشفرة"""),
        Regex("""يتم التشفير""")
    )

    private val typingPatterns = listOf(
        Regex("""^\s*typing\.{0,3}\s*$""", RegexOption.IGNORE_CASE),
        Regex("""^\s*يكتب(\s|.Now| الآن|$).{0,3}$"""),
        Regex("""^\s*يكتب الآن.{0,3}$""")
    )

    private val statusNoisePatterns = listOf(
        Regex("""^\s*(online|متصل|متصل الآن)\s*$""", RegexOption.IGNORE_CASE),
        Regex("""^\s*last seen\b.*$""", RegexOption.IGNORE_CASE),
        Regex("""^\s*آخر ظهور.*$"""),
        Regex("""^\s*(أونلاين|اونلاين)\s*$""")
    )

    private val tickWords = listOf(
        "✓", "✔", "✅", "delivered", "double check", "double tick", "tick",
        "تم التسليم", "تمت القراءة", "تم القراءة", "تم الإرسال"
    )

    private val exactTickPattern = Regex(
        "^[✓✔]{1,3}$" +
            "|^delivered$" +
            "|^read$" +
            "|^sent$" +
            "|^تم التسليم$" +
            "|^تمت القراءة$" +
            "|^تم القراءة$"
    )

    private val sendWords = listOf(
        "إرسال", "أرسل", "إرسال الرسالة", "ارسل", "send", "send message", "send now"
    )

    private val unsendWords = listOf("unsend", "إلغاء الرسالة", "سحب", "recall")

    // --------------------------------------------------------------- analysis

    fun analyze(root: AccessibilityNodeInfo?, appPackage: String): ScreenAnalysis? {
        if (root == null) return null
        return try {
            val entries = flatten(root)
            if (entries.isEmpty()) return null

            val screenRect = safeBounds(root) ?: Rect(0, 0, 1080, 1920)
            val width = screenRect.width().coerceAtLeast(1)
            val height = screenRect.height().coerceAtLeast(1)

            val inputEntry = findInputEntry(entries, height)
            val inputBounds = inputEntry?.let { safeBounds(it.node) }

            val headerLimit = (height * HEADER_RATIO).toInt()
            val contentBottom = inputBounds?.top ?: (height * 0.88f).toInt()

            val header = extractHeader(entries, headerLimit)
            val contactName = header.name
            val isTyping = detectTyping(entries, headerLimit, contentBottom)

            val candidates = collectCandidates(
                entries,
                headerLimit,
                contentBottom,
                inputBounds
            )
            // The direction is resolved from the conversation itself first: it decides
            // which bubble belongs to the user and which one to the other person.
            val direction = resolveDirection(root, header, candidates, width)
            val messages = classify(candidates, width, direction)
            val isRtlNow = direction == Direction.RTL

            val sendNode = findSendButton(root, inputBounds, isRtlNow)

            val screen = ParsedScreen(
                appPackage = appPackage,
                contactName = contactName,
                messages = messages,
                isTyping = isTyping,
                inputBounds = inputBounds,
                hasInputField = inputEntry != null,
                hasSendButton = sendNode != null,
                screenWidth = width,
                screenHeight = height,
                isRtl = isRtlNow,
                inspectedNodes = entries.size,
                parsedAt = System.currentTimeMillis()
            )
            ScreenAnalysis(
                screen = screen,
                inputNode = inputEntry?.node,
                sendNode = sendNode,
                root = root
            )
        } catch (t: Throwable) {
            null
        }
    }

    /** Locates the editable message field (bottom of the screen). */
    fun findInputField(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (root == null) return null
        return try {
            val entries = flatten(root)
            val height = (safeBounds(root)?.height() ?: 1920).coerceAtLeast(1)
            findInputEntry(entries, height)?.node
        } catch (t: Throwable) {
            null
        }
    }

    /**
     * Finds the "send" button that replaces the microphone once text is typed.
     * Three strategies, in order of reliability:
     *  1. its programmatic id / content description ("إرسال" / "Send"),
     *  2. the node id of a known send button,
     *  3. its geometric position next to the input field, on the trailing side.
     */
    fun findSendButton(root: AccessibilityNodeInfo?, inputBounds: Rect?, isRtl: Boolean): AccessibilityNodeInfo? {
        if (root == null) return null
        return try {
            val entries = flatten(root)

            // Candidates that live on the same row as the input field.
            val sameBand = entries.mapNotNull { entry ->
                val bounds = safeBounds(entry.node) ?: return@mapNotNull null
                if (bounds.width() <= 0 || bounds.height() <= 0) return@mapNotNull null
                entry to bounds
            }.filter { (_, bounds) ->
                if (inputBounds == null) return@filter true
                val overlap = minOf(bounds.bottom, inputBounds.bottom) - maxOf(bounds.top, inputBounds.top)
                overlap > (inputBounds.height() * 0.2f)
            }

            // 1. Programmatic id / content description of the send button.
            val byWord = sameBand.firstOrNull { (entry, _) ->
                val description = entry.node.contentDescription?.toString().orEmpty()
                val text = entry.node.text?.toString().orEmpty()
                val id = entry.node.viewIdResourceName.orEmpty()
                if (unsendWords.any { description.contains(it, true) }) return@firstOrNull false
                val matches = sendWords.any { description.contains(it, true) } ||
                    (text.length <= 24 && sendWords.any { text.contains(it, true) }) ||
                    (id.contains("send", true) && !id.contains("unsend", true))
                matches && (entry.node.isClickable || id.contains("send", true))
            }
            if (byWord != null) return byWord.first.node

            // 2. Geometric position: the send button replaces the microphone right next
            //    to the input field, on the trailing side of the layout.
            if (inputBounds != null) {
                val clickable = sameBand.filter { it.first.node.isClickable }
                val trailing = if (isRtl) {
                    clickable.filter { it.second.centerX() <= inputBounds.centerX() }
                        .minByOrNull { inputBounds.centerX() - it.second.centerX() }
                } else {
                    clickable.filter { it.second.centerX() >= inputBounds.centerX() }
                        .minByOrNull { it.second.centerX() - inputBounds.centerX() }
                }
                if (trailing != null) return trailing.first.node
            }

            // 3. Last resort: any node that advertises itself as a send button.
            val globalByWord = entries.firstOrNull { entry ->
                val description = entry.node.contentDescription?.toString().orEmpty()
                val id = entry.node.viewIdResourceName.orEmpty()
                !unsendWords.any { description.contains(it, true) } &&
                    (sendWords.any { description.contains(it, true) } ||
                        (id.contains("send", true) && !id.contains("unsend", true)))
            }
            globalByWord?.node
        } catch (t: Throwable) {
            null
        }
    }

    // ---------------------------------------------------------------- helpers

    private data class Entry(
        val node: AccessibilityNodeInfo,
        val depth: Int,
        val parent: AccessibilityNodeInfo?
    )

    private data class Candidate(
        val node: AccessibilityNodeInfo,
        var text: String,
        val rect: Rect,
        val hasTick: Boolean,
        /** True for a sender-name label of a group chat (never a real message). */
        var isLabel: Boolean = false,
        var attribution: String? = null
    )

    /** Layout direction of the conversation. */
    private enum class Direction { LTR, RTL }

    private data class HeaderInfo(val name: String?, val bounds: Rect?)

    /** Iterative, bounded traversal — never recursive, so no StackOverflowError. */
    private fun flatten(root: AccessibilityNodeInfo): List<Entry> {
        val out = ArrayList<Entry>(256)
        val stack = ArrayDeque<Entry>()
        stack.addLast(Entry(root, 0, null))
        var visited = 0
        while (stack.isNotEmpty()) {
            val entry = stack.removeLast()
            if (entry.depth > MAX_DEPTH) continue
            visited++
            if (visited > MAX_NODES) break
            out.add(entry)
            val childCount = try {
                entry.node.childCount
            } catch (t: Throwable) {
                0
            }
            if (childCount <= 0) continue
            for (index in 0 until childCount) {
                val child = try {
                    entry.node.getChild(index)
                } catch (t: Throwable) {
                    null
                } ?: continue
                stack.addLast(Entry(child, entry.depth + 1, entry.node))
            }
        }
        return out
    }

    private fun safeBounds(node: AccessibilityNodeInfo?): Rect? {
        if (node == null) return null
        return try {
            val rect = Rect()
            node.getBoundsInScreen(rect)
            if (rect.width() <= 0 || rect.height() <= 0) null else rect
        } catch (t: Throwable) {
            null
        }
    }

    /** Reads the window direction through reflection so no SDK level can break the build. */
    private fun nodeIsRtl(node: AccessibilityNodeInfo): Boolean {
        return try {
            val method: Method? = rtlMethod
            if (method != null) (method.invoke(node) as? Boolean) ?: false else false
        } catch (t: Throwable) {
            false
        }
    }

    private val rtlMethod: Method? by lazy {
        try {
            AccessibilityNodeInfo::class.java.getMethod("isLayoutDirectionRtl")
        } catch (t: Throwable) {
            null
        }
    }

    private fun isEditableNode(node: AccessibilityNodeInfo): Boolean {
        return try {
            if (node.isEditable) return true
            node.className?.toString()?.contains("EditText", ignoreCase = true) == true
        } catch (t: Throwable) {
            false
        }
    }

    private fun findInputEntry(entries: List<Entry>, height: Int): Entry? {
        val bottomBand = (height * 0.65f).toInt()
        return entries
            .filter { isEditableNode(it.node) }
            .filter { entry ->
                val bounds = safeBounds(entry.node) ?: return@filter false
                bounds.top >= bottomBand || bounds.bottom > height * 0.72f
            }
            .maxByOrNull { entry -> safeBounds(entry.node)?.bottom ?: 0 }
    }

    /**
     * Extracts the conversation title from the toolbar. The title always hugs the
     * leading edge of the layout, so its position also reveals the direction.
     */
    private fun extractHeader(entries: List<Entry>, headerLimit: Int): HeaderInfo {
        val candidates = entries.mapNotNull { entry ->
            val bounds = safeBounds(entry.node) ?: return@mapNotNull null
            if (bounds.bottom > headerLimit) return@mapNotNull null
            if (isEditableNode(entry.node)) return@mapNotNull null
            val text = entry.node.text?.toString()?.trim().orEmpty()
            if (text.isEmpty() || text.length > 48) return@mapNotNull null
            if (isNoise(text)) return@mapNotNull null
            entry to bounds
        }
        if (candidates.isEmpty()) return HeaderInfo(null, null)
        // The contact name is the biggest text in the toolbar.
        val best = candidates.maxByOrNull { it.second.height() } ?: return HeaderInfo(null, null)
        val name = best.first.node.text?.toString()?.trim().orEmpty()
        return HeaderInfo(name.ifBlank { null }, best.second)
    }

    /**
     * Resolves the direction of the conversation.
     *
     * 1. Delivery ticks are the strongest proof: they only exist on the user's own
     *    bubbles, and those always hug the trailing edge (right in LTR, left in RTL).
     * 2. The window itself reports its layout direction.
     * 3. The toolbar title hugs the leading edge.
     * 4. The device locale.
     */
    private fun resolveDirection(
        root: AccessibilityNodeInfo,
        header: HeaderInfo,
        candidates: List<Candidate>,
        width: Int
    ): Direction {
        val ticked = candidates.filter { it.hasTick }
        if (ticked.isNotEmpty()) {
            val avgLeftGap = ticked.sumOf { it.rect.left.toDouble() } / ticked.size
            val avgRightGap = ticked.sumOf { (width - it.rect.right).toDouble() } / ticked.size
            // The user's own bubbles always hug one edge of the conversation.
            if (minOf(avgLeftGap, avgRightGap) < width * 0.16f) {
                // Hugs the left edge  → the user writes on the left  → RTL layout.
                // Hugs the right edge → the user writes on the right → LTR layout.
                return if (avgLeftGap < avgRightGap) Direction.RTL else Direction.LTR
            }
        }
        if (nodeIsRtl(root)) return Direction.RTL
        val title = header.bounds
        if (title != null) {
            if (title.right > width * 0.58f && title.left > width * 0.26f) return Direction.RTL
            if (title.left < width * 0.44f && title.right < width * 0.74f) return Direction.LTR
        }
        if (isRtlLocale()) return Direction.RTL
        return Direction.LTR
    }

    private fun isRtlLocale(): Boolean {
        val language = Locale.getDefault().language.lowercase(Locale.ROOT)
        return language in setOf("ar", "fa", "he", "ur", "ps", "sd", "yi", "dv", "ku")
    }

    private fun detectTyping(entries: List<Entry>, headerLimit: Int, contentBottom: Int): Boolean {
        for (entry in entries) {
            val text = entry.node.text?.toString()?.trim().orEmpty()
            if (text.isEmpty()) continue
            if (typingPatterns.any { it.matches(text) }) return true
            val description = entry.node.contentDescription?.toString()?.trim().orEmpty()
            if (description.isNotEmpty() && typingPatterns.any { it.matches(description) }) return true
        }
        return false
    }

    private fun collectCandidates(
        entries: List<Entry>,
        headerLimit: Int,
        contentBottom: Int,
        inputBounds: Rect?
    ): List<Candidate> {
        // Tick markers (the double blue ticks) only ever live inside the user's own
        // bubbles. They are collected once for the whole tree, then matched against
        // every candidate in linear time — no per-bubble subtree walking.
        val parents = java.util.IdentityHashMap<AccessibilityNodeInfo, AccessibilityNodeInfo>()
        for (entry in entries) {
            entry.parent?.let { parents[entry.node] = it }
        }
        val tickHosts = java.util.Collections.newSetFromMap(
            java.util.IdentityHashMap<AccessibilityNodeInfo, Boolean>()
        )
        for (entry in entries) {
            if (!isTickNode(entry)) continue
            var current: AccessibilityNodeInfo? = entry.node
            var hops = 0
            while (current != null && hops < 6) {
                tickHosts.add(current)
                current = parents[current]
                hops++
            }
        }

        val raw = ArrayList<Candidate>()
        for (entry in entries) {
            if (raw.size >= MAX_CANDIDATES) break
            val text = entry.node.text?.toString()?.trim().orEmpty()
            if (text.isEmpty()) continue
            if (isEditableNode(entry.node)) continue
            val bounds = safeBounds(entry.node) ?: continue
            if (bounds.bottom <= headerLimit) continue
            if (bounds.top >= contentBottom) continue
            if (inputBounds != null && bounds.bottom > inputBounds.top) continue
            if (isNoise(text)) continue
            val hasTick = hasTickInBubble(entry, parents, tickHosts)
            raw.add(Candidate(entry.node, stripTrailingTimestamp(text), bounds, hasTick))
        }
        return deduplicate(raw)
    }

    /** Removes bubbles that are just a wrapper around the very same text. */
    private fun deduplicate(candidates: List<Candidate>): List<Candidate> {
        if (candidates.size <= 1) return candidates
        val result = ArrayList<Candidate>(candidates.size)
        for (candidate in candidates) {
            val duplicate = result.any { existing ->
                existing.text == candidate.text &&
                    (existing.rect.contains(candidate.rect) || candidate.rect.contains(existing.rect))
            }
            if (!duplicate) result.add(candidate)
        }
        return result
    }

    /**
     * Detects the sender-name label that group chats place above a bubble.
     *
     * The candidate is only *flagged*, never removed: a short chat message such as
     * "ok" must never disappear from the conversation, otherwise the newest bubble
     * would be lost and the agent would believe that the top of the screen holds
     * the last message. A label always has its own bubble below it, so the bottom
     * candidate of the list can never be a label.
     */
    private fun attachAttributions(candidates: List<Candidate>) {
        if (candidates.size < 2) return
        val ordered = candidates.sortedWith(compareBy({ it.rect.top }, { it.rect.bottom }))
        for (index in ordered.indices) {
            val candidate = ordered[index]
            if (candidate.text.length > 24) continue
            // A label is always followed by a taller bubble that is much wider.
            val owner = ordered.drop(index + 1).firstOrNull { other ->
                other.rect.height() >= candidate.rect.height() * 1.35f &&
                    other.rect.width() > candidate.rect.width() * 1.2f &&
                    other.rect.top >= candidate.rect.bottom - 2 &&
                    (other.rect.top - candidate.rect.bottom) <= candidate.rect.height() * 0.45f &&
                    other.text.length > candidate.text.length
            } ?: continue
            owner.attribution = candidate.text
            candidate.isLabel = true
        }
    }

    /** Decides who owns each bubble and orders them top → bottom. */
    private fun classify(
        candidates: List<Candidate>,
        width: Int,
        direction: Direction
    ): List<ParsedMessage> {
        if (candidates.isEmpty()) return emptyList()
        attachAttributions(candidates)

        // Sender labels are metadata, not messages. They are dropped from the list
        // only when a real bubble is left behind.
        val usable = candidates.filter { !it.isLabel }.ifEmpty { candidates }
        if (usable.isEmpty()) return emptyList()

        val isRtl = direction == Direction.RTL
        val ordered = usable.sortedWith(compareBy({ it.rect.top }, { it.rect.bottom }))
        val out = ArrayList<ParsedMessage>(ordered.size)
        for (candidate in ordered) {
            val trailingDistance = if (isRtl) {
                candidate.rect.left.toFloat()
            } else {
                (width - candidate.rect.right).toFloat()
            }
            val leadingDistance = if (isRtl) {
                (width - candidate.rect.right).toFloat()
            } else {
                candidate.rect.left.toFloat()
            }
            val hugTrailing = trailingDistance < width * TRAILING_HUG_RATIO
            val hugLeading = leadingDistance < width * TRAILING_HUG_RATIO
            val fullWidth = candidate.rect.width() > width * FULL_WIDTH_RATIO

            val isMine: Boolean
            val confidence: Float
            when {
                candidate.hasTick -> {
                    isMine = true
                    confidence = 1f
                }
                hugTrailing && !hugLeading -> {
                    isMine = true
                    confidence = 0.88f
                }
                hugLeading && !hugTrailing -> {
                    isMine = false
                    confidence = 0.88f
                }
                fullWidth -> {
                    // Both edges are hugged: only the delivery ticks can settle it.
                    isMine = false
                    confidence = 0.35f
                }
                else -> {
                    isMine = false
                    confidence = 0.6f
                }
            }
            out.add(
                ParsedMessage(
                    text = candidate.text,
                    isMine = isMine,
                    rect = Rect(candidate.rect),
                    confidence = confidence,
                    attribution = candidate.attribution
                )
            )
        }
        return out
    }

    /** True when the node itself is a delivery-status marker. */
    private fun isTickNode(entry: Entry): Boolean {
        val description = try {
            entry.node.contentDescription?.toString().orEmpty()
        } catch (t: Throwable) {
            ""
        }
        if (description.isNotBlank() && description.length <= 40 && tickWords.any { description.contains(it, true) }) {
            return true
        }
        val id = try {
            entry.node.viewIdResourceName.orEmpty()
        } catch (t: Throwable) {
            ""
        }
        if (id.isNotBlank() && (id.contains("tick", true) ||
                id.contains("receipt", true) ||
                id.contains("delivery", true) ||
                id.contains("status_icon", true))
        ) {
            return true
        }
        val text = try {
            entry.node.text?.toString()?.trim().orEmpty()
        } catch (t: Throwable) {
            ""
        }
        if (text.isNotEmpty() && text.length <= 14 && exactTickPattern.matches(text)) {
            val bounds = safeBounds(entry.node)
            if (bounds == null || bounds.height() <= 80) return true
        }
        return false
    }

    /** True when the bubble that owns this candidate carries a delivery tick. */
    private fun hasTickInBubble(
        entry: Entry,
        parents: Map<AccessibilityNodeInfo, AccessibilityNodeInfo>,
        tickHosts: Set<AccessibilityNodeInfo>
    ): Boolean {
        var current: AccessibilityNodeInfo? = entry.node
        var hops = 0
        while (current != null && hops < 5) {
            if (tickHosts.contains(current)) return true
            current = parents[current]
            hops++
        }
        return false
    }

    /** True when the text is a date bubble, a timestamp, a banner or a status line. */
    private fun isNoise(text: String): Boolean {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return true
        if (dateTimePatterns.any { it.matches(trimmed) }) return true
        if (bannerPatterns.any { it.containsMatchIn(trimmed) }) return true
        if (typingPatterns.any { it.matches(trimmed) }) return true
        if (statusNoisePatterns.any { it.matches(trimmed) }) return true
        if (trimmed.length <= 2 && trimmed.none { it.isLetterOrDigit() }) return true
        return false
    }

    /** Removes a trailing timestamp that some apps append to the bubble text. */
    private fun stripTrailingTimestamp(text: String): String {
        val cleaned = text.replace(
            Regex("""\s*[0-9٠-٩]{1,2}\s*[:.٫]\s*[0-9٠-٩]{2}\s*(AM|PM|am|pm|ص|م)?\s*$"""),
            ""
        ).trim()
        return cleaned.ifBlank { text.trim() }
    }
}
